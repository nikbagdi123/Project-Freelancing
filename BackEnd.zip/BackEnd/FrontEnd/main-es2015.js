(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/about-us/about-us.component.ts":
/*!************************************************!*\
  !*** ./src/app/about-us/about-us.component.ts ***!
  \************************************************/
/*! exports provided: AboutUsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutUsComponent", function() { return AboutUsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class AboutUsComponent {
    constructor() { }
    ngOnInit() {
    }
}
AboutUsComponent.ɵfac = function AboutUsComponent_Factory(t) { return new (t || AboutUsComponent)(); };
AboutUsComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AboutUsComponent, selectors: [["app-about-us"]], decls: 19, vars: 0, consts: [[1, "main-div"], [1, "aboutHead"], [1, "aboutDetails"]], template: function AboutUsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "ABOUT US");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Our story");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, " The Upwork story begins over two decades ago when the tech lead of a Silicon Valley startup realized his close friend in Athens would be perfect for a web project. The team agreed he was the best choice, but were concerned about working with someone halfway around the globe. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " The team agreed he was the best choice, but were concerned about working with someone halfway around the globe. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "A better way of working remotely");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, " In response, the two friends created a new web-based platform that brought visibility and trust to remote work. It was so successful the two realized other businesses would also benefit from reliable access to a larger pool of proven talent, while workers would enjoy freedom and flexibility to find jobs online. Together they decided to start a company that would deliver on the promise of this technology. Fast-forward to today, that technology is the foundation of Upwork \u2014 the leading flexible talent solution. With millions of jobs posted on Upwork annually, independent professionals are earning money by providing companies with over 5,000 skills across more than 70 categories of work. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "A world of opportunities");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Through Upwork, businesses get more done, connecting with proven professionals to work on projects from web and mobile app development to SEO, social media marketing, content writing, graphic design, admin help and thousands of other projects. Upwork makes it fast, simple, and cost-effective to find, hire, work with, and pay the best professionals anywhere, any time. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".main-div[_ngcontent-%COMP%]{\r\n    height: 100%;\r\n}\r\n\r\n.aboutHead[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    \r\n    background-color: #5BBC2E;\r\n    color: white;\r\n    font-size: 50px;\r\n    text-align: center;\r\n}\r\n\r\n.aboutDetails[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    \r\n    background-color: white;\r\n}\r\n\r\n.aboutDetails[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{\r\n    font-weight: bolder;\r\n    font-style:initial;\r\n    color: #1D4354;\r\n    margin-left: 35px;\r\n    margin-top: 60px;\r\n}\r\n\r\n.aboutDetails[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    font-style:initial;\r\n    color: black;\r\n    margin-left: 35px;\r\n    font-size: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWJvdXQtdXMvYWJvdXQtdXMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFDQTtJQUNJLFdBQVc7SUFDWCxtQkFBbUI7SUFDbkIsdUJBQXVCO0FBQzNCOztBQUNBO0lBQ0ksbUJBQW1CO0lBQ25CLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjs7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkIiLCJmaWxlIjoic3JjL2FwcC9hYm91dC11cy9hYm91dC11cy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4tZGl2e1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4uYWJvdXRIZWFke1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICAvKiBoZWlnaHQ6IDgwcHg7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNUJCQzJFO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiA1MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5hYm91dERldGFpbHN7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIC8qIGhlaWdodDogNzAwcHg7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4uYWJvdXREZXRhaWxzIGgxe1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgIGZvbnQtc3R5bGU6aW5pdGlhbDtcclxuICAgIGNvbG9yOiAjMUQ0MzU0O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDM1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiA2MHB4O1xyXG59XHJcbi5hYm91dERldGFpbHMgcHtcclxuICAgIGZvbnQtc3R5bGU6aW5pdGlhbDtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIG1hcmdpbi1sZWZ0OiAzNXB4O1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AboutUsComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-about-us',
                templateUrl: './about-us.component.html',
                styleUrls: ['./about-us.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/accessibility/accessibility.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/accessibility/accessibility.component.ts ***!
  \**********************************************************/
/*! exports provided: AccessibilityComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccessibilityComponent", function() { return AccessibilityComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class AccessibilityComponent {
    constructor() { }
    ngOnInit() {
    }
}
AccessibilityComponent.ɵfac = function AccessibilityComponent_Factory(t) { return new (t || AccessibilityComponent)(); };
AccessibilityComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AccessibilityComponent, selectors: [["app-accessibility"]], decls: 7, vars: 0, consts: [[1, "accessibilityDetails"]], template: function AccessibilityComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Accessibility");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Freelancing is committed to providing an accessible experience to our customers and the public, regardless of background, nationality, race, ethnicity, gender, gender identity, sexual orientation, disability status, veteran status, or other similarly protected characteristics. This Freelancing Digital Accessibility Statement concerns our commitment to providing access to persons with disabilities. Please also see our Nondiscrimination Statement.Please contact our Accessibility Coordinator at accessibilitycoordinator@Freelancing.com or send a letter addressed to: Attn: Accessibility Coordinator, 2625 Augustine Drive, Suite 601, Santa Clara, CA 95054, USA, to learn more about accessibility support services Freelancing.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Individuals who need a reasonable accommodation to access Freelancing\u2019s services and information should send an email to accessibilitycoordinator@Freelancing.com or send a letter addressed to: Attn: Accessibility Coordinator, 2625 Augustine Drive, Suite 601, Santa Clara, CA 95054, USA to provide information about the nature of the requested accommodation. Requesters must include contact information such as an email address or telephone number at which they can be reached. Depending on the nature of the request, Freelancing may need sufficient notice to provide a reasonable accommodation.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".PPaccessibilityDetails[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: white;\r\n    color: black;\r\n}\r\n.accessibilityDetails[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n    font-weight: bolder;\r\n    color: black;\r\n    margin-left: 30px;\r\n}\r\n.accessibilityDetails[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-left: 30px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWNjZXNzaWJpbGl0eS9hY2Nlc3NpYmlsaXR5LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtJQUNaLHVCQUF1QjtJQUN2QixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxtQkFBbUI7SUFDbkIsWUFBWTtJQUNaLGlCQUFpQjtBQUNyQjtBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCIiwiZmlsZSI6InNyYy9hcHAvYWNjZXNzaWJpbGl0eS9hY2Nlc3NpYmlsaXR5LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuUFBhY2Nlc3NpYmlsaXR5RGV0YWlsc3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbn1cclxuLmFjY2Vzc2liaWxpdHlEZXRhaWxzIGgye1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG59XHJcbi5hY2Nlc3NpYmlsaXR5RGV0YWlscyBwe1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AccessibilityComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-accessibility',
                templateUrl: './accessibility.component.html',
                styleUrls: ['./accessibility.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _main_page_main_page_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main-page/main-page.component */ "./src/app/main-page/main-page.component.ts");
/* harmony import */ var _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mainpage-home/mainpage-home.component */ "./src/app/mainpage-home/mainpage-home.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _contact_contact_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./contact/contact.component */ "./src/app/contact/contact.component.ts");
/* harmony import */ var _signup_signup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signup/signup.component */ "./src/app/signup/signup.component.ts");
/* harmony import */ var _about_us_about_us_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./about-us/about-us.component */ "./src/app/about-us/about-us.component.ts");
/* harmony import */ var _terms_of_services_terms_of_services_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./terms-of-services/terms-of-services.component */ "./src/app/terms-of-services/terms-of-services.component.ts");
/* harmony import */ var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./privacy-policy/privacy-policy.component */ "./src/app/privacy-policy/privacy-policy.component.ts");
/* harmony import */ var _accessibility_accessibility_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./accessibility/accessibility.component */ "./src/app/accessibility/accessibility.component.ts");
/* harmony import */ var _resources_resources_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./resources/resources.component */ "./src/app/resources/resources.component.ts");
/* harmony import */ var _customer_support_customer_support_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./customer-support/customer-support.component */ "./src/app/customer-support/customer-support.component.ts");
/* harmony import */ var _customer_stories_customer_stories_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./customer-stories/customer-stories.component */ "./src/app/customer-stories/customer-stories.component.ts");
/* harmony import */ var _business_resources_business_resources_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./business-resources/business-resources.component */ "./src/app/business-resources/business-resources.component.ts");
/* harmony import */ var _freelancers_by_skill_freelancers_by_skill_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./freelancers-by-skill/freelancers-by-skill.component */ "./src/app/freelancers-by-skill/freelancers-by-skill.component.ts");
/* harmony import */ var _find_developers_find_developers_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./find-developers/find-developers.component */ "./src/app/find-developers/find-developers.component.ts");
/* harmony import */ var _who_you_are_who_you_are_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./who-you-are/who-you-are.component */ "./src/app/who-you-are/who-you-are.component.ts");
/* harmony import */ var _developer_dash_board_developer_dash_board_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./developer-dash-board/developer-dash-board.component */ "./src/app/developer-dash-board/developer-dash-board.component.ts");
/* harmony import */ var _search_result_search_result_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./search-result/search-result.component */ "./src/app/search-result/search-result.component.ts");
/* harmony import */ var _devpofile_devpofile_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./devpofile/devpofile.component */ "./src/app/devpofile/devpofile.component.ts");
/* harmony import */ var _loding_screen_loding_screen_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./loding-screen/loding-screen.component */ "./src/app/loding-screen/loding-screen.component.ts");
























const routes = [{ path: "", component: _loding_screen_loding_screen_component__WEBPACK_IMPORTED_MODULE_21__["LodingScreenComponent"] },
    { path: "mainpage", component: _main_page_main_page_component__WEBPACK_IMPORTED_MODULE_2__["MainPageComponent"],
        children: [{ path: '', component: _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_3__["MainpageHomeComponent"] },
            { path: 'home', component: _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_3__["MainpageHomeComponent"], children: [] },
            { path: 'signin', component: _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"] },
            { path: 'contact', component: _contact_contact_component__WEBPACK_IMPORTED_MODULE_5__["ContactComponent"] },
            { path: 'signup', component: _signup_signup_component__WEBPACK_IMPORTED_MODULE_6__["SignupComponent"] },
            { path: 'aboutUs', component: _about_us_about_us_component__WEBPACK_IMPORTED_MODULE_7__["AboutUsComponent"] },
            { path: 'termsOfService', component: _terms_of_services_terms_of_services_component__WEBPACK_IMPORTED_MODULE_8__["TermsOfServicesComponent"] },
            { path: 'privacyPolicy', component: _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_9__["PrivacyPolicyComponent"] },
            { path: 'accessibility', component: _accessibility_accessibility_component__WEBPACK_IMPORTED_MODULE_10__["AccessibilityComponent"] },
            { path: 'resources', component: _resources_resources_component__WEBPACK_IMPORTED_MODULE_11__["ResourcesComponent"] },
            { path: 'customerSupport', component: _customer_support_customer_support_component__WEBPACK_IMPORTED_MODULE_12__["CustomerSupportComponent"] },
            { path: 'customerStories', component: _customer_stories_customer_stories_component__WEBPACK_IMPORTED_MODULE_13__["CustomerStoriesComponent"] },
            { path: 'businessResources', component: _business_resources_business_resources_component__WEBPACK_IMPORTED_MODULE_14__["BusinessResourcesComponent"] },
            { path: 'freelancersBySkill', component: _freelancers_by_skill_freelancers_by_skill_component__WEBPACK_IMPORTED_MODULE_15__["FreelancersBySkillComponent"] },
            { path: 'findDevelopers', component: _find_developers_find_developers_component__WEBPACK_IMPORTED_MODULE_16__["FindDevelopersComponent"] },
            { path: 'who-you-are', component: _who_you_are_who_you_are_component__WEBPACK_IMPORTED_MODULE_17__["WhoYouAreComponent"] },
        ]
    },
    { path: 'dev-dashboard', component: _developer_dash_board_developer_dash_board_component__WEBPACK_IMPORTED_MODULE_18__["DeveloperDashBoardComponent"] },
    { path: 'searchResult', component: _search_result_search_result_component__WEBPACK_IMPORTED_MODULE_19__["SearchResultComponent"] },
    { path: 'devprofile', component: _devpofile_devpofile_component__WEBPACK_IMPORTED_MODULE_20__["DevpofileComponent"] }
];
class AppRoutingModule {
}
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ factory: function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); }, imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppRoutingModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
                exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class AppComponent {
    constructor() {
        this.title = 'freelancing';
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AppComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-root',
                templateUrl: './app.component.html',
                styleUrls: ['./app.component.css']
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mainpage-header/mainpage-header.component */ "./src/app/mainpage-header/mainpage-header.component.ts");
/* harmony import */ var _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mainpage-footer/mainpage-footer.component */ "./src/app/mainpage-footer/mainpage-footer.component.ts");
/* harmony import */ var _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mainpage-home/mainpage-home.component */ "./src/app/mainpage-home/mainpage-home.component.ts");
/* harmony import */ var _main_page_main_page_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./main-page/main-page.component */ "./src/app/main-page/main-page.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _contact_contact_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./contact/contact.component */ "./src/app/contact/contact.component.ts");
/* harmony import */ var _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./signup/signup.component */ "./src/app/signup/signup.component.ts");
/* harmony import */ var _about_us_about_us_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./about-us/about-us.component */ "./src/app/about-us/about-us.component.ts");
/* harmony import */ var _terms_of_services_terms_of_services_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./terms-of-services/terms-of-services.component */ "./src/app/terms-of-services/terms-of-services.component.ts");
/* harmony import */ var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./privacy-policy/privacy-policy.component */ "./src/app/privacy-policy/privacy-policy.component.ts");
/* harmony import */ var _accessibility_accessibility_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./accessibility/accessibility.component */ "./src/app/accessibility/accessibility.component.ts");
/* harmony import */ var _resources_resources_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./resources/resources.component */ "./src/app/resources/resources.component.ts");
/* harmony import */ var _customer_support_customer_support_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./customer-support/customer-support.component */ "./src/app/customer-support/customer-support.component.ts");
/* harmony import */ var _customer_stories_customer_stories_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./customer-stories/customer-stories.component */ "./src/app/customer-stories/customer-stories.component.ts");
/* harmony import */ var _business_resources_business_resources_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./business-resources/business-resources.component */ "./src/app/business-resources/business-resources.component.ts");
/* harmony import */ var _freelancers_by_skill_freelancers_by_skill_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./freelancers-by-skill/freelancers-by-skill.component */ "./src/app/freelancers-by-skill/freelancers-by-skill.component.ts");
/* harmony import */ var _find_developers_find_developers_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./find-developers/find-developers.component */ "./src/app/find-developers/find-developers.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _who_you_are_who_you_are_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./who-you-are/who-you-are.component */ "./src/app/who-you-are/who-you-are.component.ts");
/* harmony import */ var _developer_dash_board_developer_dash_board_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./developer-dash-board/developer-dash-board.component */ "./src/app/developer-dash-board/developer-dash-board.component.ts");
/* harmony import */ var _search_result_search_result_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./search-result/search-result.component */ "./src/app/search-result/search-result.component.ts");
/* harmony import */ var _devpofile_devpofile_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./devpofile/devpofile.component */ "./src/app/devpofile/devpofile.component.ts");
/* harmony import */ var _header_of_deshboard_header_of_deshboard_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./header-of-deshboard/header-of-deshboard.component */ "./src/app/header-of-deshboard/header-of-deshboard.component.ts");
/* harmony import */ var _loding_screen_loding_screen_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./loding-screen/loding-screen.component */ "./src/app/loding-screen/loding-screen.component.ts");
/* harmony import */ var _search_result_header_search_result_header_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./search-result-header/search-result-header.component */ "./src/app/search-result-header/search-result-header.component.ts");































class AppModule {
}
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ factory: function AppModule_Factory(t) { return new (t || AppModule)(); }, providers: [], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_21__["FormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_22__["HttpClientModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
        _mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_4__["MainpageHeaderComponent"],
        _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_5__["MainpageFooterComponent"],
        _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_6__["MainpageHomeComponent"],
        _main_page_main_page_component__WEBPACK_IMPORTED_MODULE_7__["MainPageComponent"],
        _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"],
        _contact_contact_component__WEBPACK_IMPORTED_MODULE_9__["ContactComponent"],
        _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__["SignupComponent"],
        _about_us_about_us_component__WEBPACK_IMPORTED_MODULE_11__["AboutUsComponent"],
        _terms_of_services_terms_of_services_component__WEBPACK_IMPORTED_MODULE_12__["TermsOfServicesComponent"],
        _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_13__["PrivacyPolicyComponent"],
        _accessibility_accessibility_component__WEBPACK_IMPORTED_MODULE_14__["AccessibilityComponent"],
        _resources_resources_component__WEBPACK_IMPORTED_MODULE_15__["ResourcesComponent"],
        _customer_support_customer_support_component__WEBPACK_IMPORTED_MODULE_16__["CustomerSupportComponent"],
        _customer_stories_customer_stories_component__WEBPACK_IMPORTED_MODULE_17__["CustomerStoriesComponent"],
        _business_resources_business_resources_component__WEBPACK_IMPORTED_MODULE_18__["BusinessResourcesComponent"],
        _freelancers_by_skill_freelancers_by_skill_component__WEBPACK_IMPORTED_MODULE_19__["FreelancersBySkillComponent"],
        _find_developers_find_developers_component__WEBPACK_IMPORTED_MODULE_20__["FindDevelopersComponent"],
        _who_you_are_who_you_are_component__WEBPACK_IMPORTED_MODULE_23__["WhoYouAreComponent"],
        _developer_dash_board_developer_dash_board_component__WEBPACK_IMPORTED_MODULE_24__["DeveloperDashBoardComponent"],
        _search_result_search_result_component__WEBPACK_IMPORTED_MODULE_25__["SearchResultComponent"],
        _devpofile_devpofile_component__WEBPACK_IMPORTED_MODULE_26__["DevpofileComponent"],
        _header_of_deshboard_header_of_deshboard_component__WEBPACK_IMPORTED_MODULE_27__["HeaderOfDeshboardComponent"],
        _loding_screen_loding_screen_component__WEBPACK_IMPORTED_MODULE_28__["LodingScreenComponent"],
        _search_result_header_search_result_header_component__WEBPACK_IMPORTED_MODULE_29__["SearchResultHeaderComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_21__["FormsModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_22__["HttpClientModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](AppModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"],
        args: [{
                declarations: [
                    _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                    _mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_4__["MainpageHeaderComponent"],
                    _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_5__["MainpageFooterComponent"],
                    _mainpage_home_mainpage_home_component__WEBPACK_IMPORTED_MODULE_6__["MainpageHomeComponent"],
                    _main_page_main_page_component__WEBPACK_IMPORTED_MODULE_7__["MainPageComponent"],
                    _login_login_component__WEBPACK_IMPORTED_MODULE_8__["LoginComponent"],
                    _contact_contact_component__WEBPACK_IMPORTED_MODULE_9__["ContactComponent"],
                    _signup_signup_component__WEBPACK_IMPORTED_MODULE_10__["SignupComponent"],
                    _about_us_about_us_component__WEBPACK_IMPORTED_MODULE_11__["AboutUsComponent"],
                    _terms_of_services_terms_of_services_component__WEBPACK_IMPORTED_MODULE_12__["TermsOfServicesComponent"],
                    _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_13__["PrivacyPolicyComponent"],
                    _accessibility_accessibility_component__WEBPACK_IMPORTED_MODULE_14__["AccessibilityComponent"],
                    _resources_resources_component__WEBPACK_IMPORTED_MODULE_15__["ResourcesComponent"],
                    _customer_support_customer_support_component__WEBPACK_IMPORTED_MODULE_16__["CustomerSupportComponent"],
                    _customer_stories_customer_stories_component__WEBPACK_IMPORTED_MODULE_17__["CustomerStoriesComponent"],
                    _business_resources_business_resources_component__WEBPACK_IMPORTED_MODULE_18__["BusinessResourcesComponent"],
                    _freelancers_by_skill_freelancers_by_skill_component__WEBPACK_IMPORTED_MODULE_19__["FreelancersBySkillComponent"],
                    _find_developers_find_developers_component__WEBPACK_IMPORTED_MODULE_20__["FindDevelopersComponent"],
                    _who_you_are_who_you_are_component__WEBPACK_IMPORTED_MODULE_23__["WhoYouAreComponent"],
                    _developer_dash_board_developer_dash_board_component__WEBPACK_IMPORTED_MODULE_24__["DeveloperDashBoardComponent"],
                    _search_result_search_result_component__WEBPACK_IMPORTED_MODULE_25__["SearchResultComponent"],
                    _devpofile_devpofile_component__WEBPACK_IMPORTED_MODULE_26__["DevpofileComponent"],
                    _header_of_deshboard_header_of_deshboard_component__WEBPACK_IMPORTED_MODULE_27__["HeaderOfDeshboardComponent"],
                    _loding_screen_loding_screen_component__WEBPACK_IMPORTED_MODULE_28__["LodingScreenComponent"],
                    _search_result_header_search_result_header_component__WEBPACK_IMPORTED_MODULE_29__["SearchResultHeaderComponent"]
                ],
                imports: [
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                    _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
                    _angular_forms__WEBPACK_IMPORTED_MODULE_21__["FormsModule"],
                    _angular_common_http__WEBPACK_IMPORTED_MODULE_22__["HttpClientModule"]
                ],
                providers: [],
                bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/business-resources/business-resources.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/business-resources/business-resources.component.ts ***!
  \********************************************************************/
/*! exports provided: BusinessResourcesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinessResourcesComponent", function() { return BusinessResourcesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class BusinessResourcesComponent {
    constructor() { }
    ngOnInit() {
    }
}
BusinessResourcesComponent.ɵfac = function BusinessResourcesComponent_Factory(t) { return new (t || BusinessResourcesComponent)(); };
BusinessResourcesComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: BusinessResourcesComponent, selectors: [["app-business-resources"]], decls: 6, vars: 0, consts: [[1, "brHead"]], template: function BusinessResourcesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Business Resources ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " Freelancing connects freelancers and clients to service providers ready to help your business grow. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " Check back often, as we\u2019ll continue to add more local resources. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".brHead[_ngcontent-%COMP%]{\r\n    text-align: center;\r\n    width: 100%;\r\n    height: 200px;\r\n    color: white;\r\n    background-color: #6FDA44;\r\n    font-size: 50px;\r\n}\r\n.brHead[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    font-size: 25px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYnVzaW5lc3MtcmVzb3VyY2VzL2J1c2luZXNzLXJlc291cmNlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7SUFDWCxhQUFhO0lBQ2IsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixlQUFlO0FBQ25CO0FBQ0E7SUFDSSxlQUFlO0FBQ25CIiwiZmlsZSI6InNyYy9hcHAvYnVzaW5lc3MtcmVzb3VyY2VzL2J1c2luZXNzLXJlc291cmNlcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJySGVhZHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM2RkRBNDQ7XHJcbiAgICBmb250LXNpemU6IDUwcHg7XHJcbn1cclxuLmJySGVhZCBwe1xyXG4gICAgZm9udC1zaXplOiAyNXB4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BusinessResourcesComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-business-resources',
                templateUrl: './business-resources.component.html',
                styleUrls: ['./business-resources.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/contact/contact.component.ts":
/*!**********************************************!*\
  !*** ./src/app/contact/contact.component.ts ***!
  \**********************************************/
/*! exports provided: ContactComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactComponent", function() { return ContactComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class ContactComponent {
    constructor() { }
    ngOnInit() {
    }
}
ContactComponent.ɵfac = function ContactComponent_Factory(t) { return new (t || ContactComponent)(); };
ContactComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ContactComponent, selectors: [["app-contact"]], decls: 9, vars: 0, consts: [[1, "contactHead"]], template: function ContactComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Contact Us :");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Email Us : taruntailor7@gmail.com ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Mobile No. : 8000808594 , 7737233212 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " WhatsAPP : 8000808594 , 7737233212 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".contactHead[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 170px;\r\n    background-color: #6FDA44;\r\n    color: white;\r\n}\r\n.contactHead[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{\r\n    margin-left: 40px;\r\n}\r\n.contactHead[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-left: 40px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29udGFjdC9jb250YWN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsYUFBYTtJQUNiLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxpQkFBaUI7QUFDckI7QUFDQTtJQUNJLGlCQUFpQjtBQUNyQiIsImZpbGUiOiJzcmMvYXBwL2NvbnRhY3QvY29udGFjdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhY3RIZWFke1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDE3MHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzZGREE0NDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG4uY29udGFjdEhlYWQgaDF7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxufVxyXG4uY29udGFjdEhlYWQgcHtcclxuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ContactComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-contact',
                templateUrl: './contact.component.html',
                styleUrls: ['./contact.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/customer-stories/customer-stories.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/customer-stories/customer-stories.component.ts ***!
  \****************************************************************/
/*! exports provided: CustomerStoriesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerStoriesComponent", function() { return CustomerStoriesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class CustomerStoriesComponent {
    constructor() { }
    ngOnInit() {
    }
}
CustomerStoriesComponent.ɵfac = function CustomerStoriesComponent_Factory(t) { return new (t || CustomerStoriesComponent)(); };
CustomerStoriesComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CustomerStoriesComponent, selectors: [["app-customer-stories"]], decls: 3, vars: 0, consts: [[1, "storyHead"]], template: function CustomerStoriesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "You can write your stories or reviews here");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".storyHead[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 80px;\r\n    background-color: #6FDA44;\r\n}\r\n.storyHead[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{\r\n    margin-top:30px;\r\n    margin-left: 60px; \r\n    font-size: 50px;\r\n    color: white;\r\n\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tZXItc3Rvcmllcy9jdXN0b21lci1zdG9yaWVzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtJQUNaLHlCQUF5QjtBQUM3QjtBQUNBO0lBQ0ksZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixlQUFlO0lBQ2YsWUFBWTs7QUFFaEIiLCJmaWxlIjoic3JjL2FwcC9jdXN0b21lci1zdG9yaWVzL2N1c3RvbWVyLXN0b3JpZXMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdG9yeUhlYWR7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM2RkRBNDQ7XHJcbn1cclxuLnN0b3J5SGVhZCBoMXtcclxuICAgIG1hcmdpbi10b3A6MzBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA2MHB4OyBcclxuICAgIGZvbnQtc2l6ZTogNTBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuXHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CustomerStoriesComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-customer-stories',
                templateUrl: './customer-stories.component.html',
                styleUrls: ['./customer-stories.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/customer-support/customer-support.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/customer-support/customer-support.component.ts ***!
  \****************************************************************/
/*! exports provided: CustomerSupportComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerSupportComponent", function() { return CustomerSupportComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class CustomerSupportComponent {
    constructor() { }
    ngOnInit() {
    }
}
CustomerSupportComponent.ɵfac = function CustomerSupportComponent_Factory(t) { return new (t || CustomerSupportComponent)(); };
CustomerSupportComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CustomerSupportComponent, selectors: [["app-customer-support"]], decls: 5, vars: 0, consts: [[1, "csHead"]], template: function CustomerSupportComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "How can we help you?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Email Us : taruntailor7@gmail.com ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".csHead[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 150px;\r\n    background-color:#6FDA44;\r\n    color: white;\r\n}\r\n.csHead[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{\r\n    margin-top:30px;\r\n    margin-left: 60px; \r\n    font-size: 50px;\r\n\r\n}\r\n.csHead[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-top:30px;\r\n    margin-left: 60px; \r\n    font-size: 30px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tZXItc3VwcG9ydC9jdXN0b21lci1zdXBwb3J0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsYUFBYTtJQUNiLHdCQUF3QjtJQUN4QixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLGVBQWU7O0FBRW5CO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkIiLCJmaWxlIjoic3JjL2FwcC9jdXN0b21lci1zdXBwb3J0L2N1c3RvbWVyLXN1cHBvcnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jc0hlYWR7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiM2RkRBNDQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuLmNzSGVhZCBoMXtcclxuICAgIG1hcmdpbi10b3A6MzBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA2MHB4OyBcclxuICAgIGZvbnQtc2l6ZTogNTBweDtcclxuXHJcbn1cclxuLmNzSGVhZCBwe1xyXG4gICAgbWFyZ2luLXRvcDozMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDYwcHg7IFxyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](CustomerSupportComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-customer-support',
                templateUrl: './customer-support.component.html',
                styleUrls: ['./customer-support.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/data.service.ts":
/*!*********************************!*\
  !*** ./src/app/data.service.ts ***!
  \*********************************/
/*! exports provided: DataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");



class DataService {
    constructor(http) {
        this.http = http;
        this.baseURL = "http://13.59.163.207/";
    }
    signUp(data) {
        return this.http.post(this.baseURL + "/sign-up", data);
    }
    signIn(data) {
        // return this.http.post(this.baseURL+"/sign-in", data);
        return this.http.post(this.baseURL + "/sign-up-chek", data);
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
DataService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DataService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/devdata.service.ts":
/*!************************************!*\
  !*** ./src/app/devdata.service.ts ***!
  \************************************/
/*! exports provided: DevdataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DevdataService", function() { return DevdataService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");



class DevdataService {
    constructor(http) {
        this.http = http;
        this.baseURL = "http://13.59.163.207/";
    }
    save(data) {
        return this.http.post(this.baseURL + "/dev", data);
    }
    GetDevData() {
        return this.http.get(this.baseURL + "/dev");
    }
    uploadImg(data) {
        return this.http.post(this.baseURL + "/images", data);
    }
    sendMail(data) {
        return this.http.post(this.baseURL + "/sendmail", data);
    }
    updateData(data) {
        return this.http.post(this.baseURL + "/devUpdate", data);
    }
}
DevdataService.ɵfac = function DevdataService_Factory(t) { return new (t || DevdataService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"])); };
DevdataService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DevdataService, factory: DevdataService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DevdataService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return [{ type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }]; }, null); })();


/***/ }),

/***/ "./src/app/developer-dash-board/developer-dash-board.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/developer-dash-board/developer-dash-board.component.ts ***!
  \************************************************************************/
/*! exports provided: DeveloperDashBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeveloperDashBoardComponent", function() { return DeveloperDashBoardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _devdata_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../devdata.service */ "./src/app/devdata.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _header_of_deshboard_header_of_deshboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../header-of-deshboard/header-of-deshboard.component */ "./src/app/header-of-deshboard/header-of-deshboard.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../mainpage-footer/mainpage-footer.component */ "./src/app/mainpage-footer/mainpage-footer.component.ts");







class DeveloperDashBoardComponent {
    constructor(ds, router) {
        this.ds = ds;
        this.router = router;
        this.isDevData = false;
        this.buttonText = "SAVE";
        this.categoryList = ['web', 'app'];
        this.variableColor = "red";
        this.email = "";
        this.name = "";
        this.categoryProp = "";
        this.experienceProp = "1";
        this.degreeProp = "";
        this.rateProp = "";
        this.locProp = "";
        this.titleProp = "";
        this.disProp = "";
        this.UnameProp = "";
        this.skillsProp = "";
        // url
        this.facebookUrl = "https://www.facebook.com/";
        this.instaUrl = "https://www.instagram.com/";
        this.twitterUrl = "https://twitter.com/";
        this.found = false;
    }
    ngOnInit() {
        this.email = localStorage.getItem("email");
        this.name = localStorage.getItem("name")[0].toUpperCase() + localStorage.getItem("name").slice(1);
        this.ds.GetDevData().subscribe(res => {
            if (res.status = "ok") {
                res.data.forEach(element => {
                    // console.log("in onit")
                    // console.log(element.email)
                    if (element.email == this.email) {
                        this.isDevData = true;
                        console.log(element.email);
                        this.buttonText = "UPDATE";
                        this.disProp = element.discription;
                        this.titleProp = element.title;
                        this.categoryProp = element.category;
                        this.experienceProp = element.experience;
                        this.degreeProp = element.degree;
                        this.rateProp = element.rate;
                        this.locProp = element.location;
                        this.lanProp = element.language;
                        this.UnameProp = element.university;
                        this.skillsProp = element.skills;
                        this.facebookUrl = element.facebookUrl;
                        this.instaUrl = element.instaUrl;
                        this.twitterUrl = element.instaUrl;
                    }
                });
            }
        });
    }
    getProfile(e) {
        this.profile = e.target.files[0];
    }
    save(cat, exp, uname, deg, skills, rate, loc, lan, title, dis) {
        if (cat != "" && exp != "" && uname != "" && deg != "" && skills != "" && rate != "" && loc != "" && lan != "" && title != "" && dis != "" && this.profile != undefined) {
            var form = new FormData();
            // for (var i=0; i<this.gallery.length;i++)
            // {
            //   form.append("gallery",this.gallery[i], this.gallery[i]['name']);
            // }
            form.set('name', this.name);
            form.set('category', cat);
            form.set('experience', exp);
            form.set('university', uname);
            form.set('degree', deg);
            form.set('skills', skills);
            form.set('rate', rate);
            form.set('location', loc);
            form.set('language', lan);
            form.set('title', title);
            form.set('discription', dis);
            form.set('facebookUrl', this.facebookUrl);
            form.set('instaUrl', this.instaUrl);
            form.set('twitterUrl', this.twitterUrl);
            form.set('email', this.email);
            form.set('profile', this.profile);
            if (this.isDevData == false) {
                this.ds.uploadImg(form).subscribe((d) => {
                    if (d.status == "ok") {
                        this.variable = "Data saved Successfull You will redirect to home in 3 seconds";
                        this.variableColor = "green";
                        setTimeout(() => {
                            this.router.navigate(['/mainpage/home']);
                        }, 3000);
                    }
                    else {
                        this.variable = "Data Is Already saved";
                        setTimeout(() => {
                            this.router.navigate(['/mainpage/home']);
                        }, 3000);
                        this.variableColor = "red";
                    }
                });
            }
            else {
                this.ds.updateData({
                    name: this.name,
                    email: this.email,
                    category: cat,
                    experience: exp,
                    university: uname,
                    degree: deg,
                    skills: skills,
                    rate: rate,
                    location: loc,
                    language: lan,
                    title: title,
                    discription: dis,
                    facebookUrl: this.facebookUrl,
                    instaUrl: this.instaUrl,
                    twitterUrl: this.twitterUrl
                }).subscribe(res => {
                    if (res.status == "ok") {
                        alert("data updated!");
                    }
                    else {
                        alert("data not updated!");
                    }
                    // console.log(res)
                });
            }
        }
        else {
            alert("please fill all fields");
        }
        //   var found=false;
        //   this.catagoryProp=cat
        //   this.experienceProp=exp
        //   this.degreeProp=deg
        //   this.rateProp=rate
        //   this.locProp=loc
        //   this.lanProp=lan
        //   this.titleProp=title
        //   this.disProp=dis
        //   this.UnameProp=uname
        //   var skillsArray=skills.split(",")
        //   console.log(skillsArray)
        //  if(this.email!=""){
        //     console.log("in if")
        //         this.ds.GetDevData().subscribe(res=>{
        //           if(res.status=="ok"){
        //           res.data.forEach(element => {
        //             console.log(element.email,this.email)
        //             if(element.email==this.email){
        //               console.log(element.email)
        //               found=true
        //             }
        //           });
        //           console.log(found,res.status)
        //           this.insertData(found,res,skillsArray)
        //         }
        //         else
        //        {
        //         this.insertData(found,res,skillsArray)
        //        }
        //         })
        // console.log(found)
        // }
    }
}
DeveloperDashBoardComponent.ɵfac = function DeveloperDashBoardComponent_Factory(t) { return new (t || DeveloperDashBoardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"])); };
DeveloperDashBoardComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DeveloperDashBoardComponent, selectors: [["app-developer-dash-board"]], decls: 168, vars: 19, consts: [[1, "greeting"], [1, "one"], [1, "two"], [1, "p1"], ["ngNativeValidate", ""], ["f", "ngForm"], ["for", "avatar"], ["name", "img", "required", "", "type", "file", "ngModel", "", "name", "avatar", "id", "avatar", 1, "form-control", 3, "change"], ["imgRef", "ngModel"], ["for", "category"], ["name", "category", "id", "category", 1, "form-control", 3, "value"], ["cat", ""], ["value", "fullstack developer", 1, "dropdown-item"], ["value", "android developer"], ["value", "apple developer"], ["value", "software developer"], ["value", "writing"], ["value", "designing"], ["value", "dataScience"], ["value", "marketing"], ["for", "year"], ["name", "year", "id", "year", 1, "form-control", 3, "value"], ["exp", ""], ["value", "1"], ["value", "2", 3, "value"], ["value", "3"], ["value", "4"], ["value", "5"], ["value", "more than 5"], ["for", "university"], ["type", "text", "id", "university", 1, "form-control", 3, "value"], ["uname", ""], ["for", "degree"], ["name", "degree", "id", "degree", 1, "form-control", 3, "value"], ["deg", ""], ["value", "btech"], ["value", "mtech"], ["value", "mba"], ["value", "bsc"], ["value", "bca"], ["value", "mca"], ["for", "skills"], ["name", "skills", "id", "skills", "cols", "10", "rows", "3", "placeholder", "type multiple skills by giving comma(',')", 1, "form-control", 3, "value"], ["skills", ""], ["for", "charge"], ["type", "number", "name", "", "id", "charge", "required", "", 1, "form-control", 3, "value"], ["rate", ""], ["for", "location"], ["type", "text", "name", "", "id", "location", "required", "", 1, "form-control", 3, "value"], ["loc", ""], ["for", "lang"], ["name", "lang", "id", "lang", 1, "form-control", 3, "value"], ["lan", ""], ["value", "english"], ["value", "hindi"], ["value", "urdu"], ["value", "panjabi"], [2, "margin-top", "50px", "color", "green"], ["for", "title"], ["type", "text", 1, "form-control", 3, "value"], ["title", ""], ["for", "discription"], ["name", "discription", "id", "discription", "cols", "20", "rows", "5", 1, "form-control", 3, "value"], ["dis", ""], ["type", "text", "name", "facebook", "placeholder", "link of your facebook profile", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "text", "name", "insta", "placeholder", "link of your insta profile", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "text", "name", "twitter", "placeholder", "link of your twitter profile", 1, "form-control", 3, "ngModel", "ngModelChange"], ["id", "alerttext", 3, "innerHTML"], ["type", "submit", 1, "btn", "btn-success", 3, "innerHTML", "click"]], template: function DeveloperDashBoardComponent_Template(rf, ctx) { if (rf & 1) {
        const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-header-of-deshboard");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Welcome ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Put Your Details: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "form", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "table");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Profile Picture:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "input", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("change", function DeveloperDashBoardComponent_Template_input_change_18_listener($event) { return ctx.getProfile($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Choose Category:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "select", 10, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "Fullstack Developer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Android Developer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Apple Developer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Software Developer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](36, "Writing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Designing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](40, "Data Science");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Marketing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](44, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "Year Of Experience:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "select", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](50, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](51, "1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "option", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, "2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "option", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](55, "3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, "4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](58, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](59, "5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "option", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "More than 5 year");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "label", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65, "University Name:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "input", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](69, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](71, "label", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](72, "Degree:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](74, "select", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "option", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](77, "BTech.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](78, "option", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](79, "MTech.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "option", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](81, "MBA");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](83, "BSC");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](84, "option", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](85, "BCA");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](86, "option", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](87, "MCA");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](88, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](89, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](90, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](91, "Skills You have:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](92, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](93, "textarea", 42, 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](95, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](96, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](97, "label", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](98, " $ Hourly Rate: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](99, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](100, "input", 45, 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](102, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](103, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](104, "label", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](105, "Location:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](106, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](107, "input", 48, 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](109, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](110, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](111, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](112, "Communication Language :");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](113, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](114, "select", 51, 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](116, "option", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](117, "English");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](118, "option", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](119, "Hindi");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](120, "option", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](121, "Germany");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](122, "option", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](123, "Japanies");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](124, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](125, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](126, "h3", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](127, "Title & Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](128, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](129, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](130, "label", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](131, "Title:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](132, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](133, "input", 59, 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](135, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](136, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](137, "label", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](138, "Description:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](139, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](140, "textarea", 62, 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](142, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](143, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](144, "h3", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](145, "Social Media Accounts ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](146, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](147, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](148, "label", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](149, "Facebook:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](150, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](151, "input", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DeveloperDashBoardComponent_Template_input_ngModelChange_151_listener($event) { return ctx.facebookUrl = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](152, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](153, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](154, "label", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](155, "Instagram:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](156, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](157, "input", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DeveloperDashBoardComponent_Template_input_ngModelChange_157_listener($event) { return ctx.instaUrl = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](158, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](159, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](160, "label", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](161, "Twitter:");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](162, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](163, "input", 66, 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DeveloperDashBoardComponent_Template_input_ngModelChange_163_listener($event) { return ctx.twitterUrl = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](165, "h5", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](166, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeveloperDashBoardComponent_Template_button_click_166_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](26); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](49); const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](68); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](75); const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](94); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](101); const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](108); const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](115); const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](134); const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](141); return ctx.save(_r2.value, _r3.value, _r4.value, _r5.value, _r6.value, _r7.value, _r8.value, _r9.value, _r10.value, _r11.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](167, "app-mainpage-footer");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.categoryProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.experienceProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.UnameProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.degreeProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.skillsProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.rateProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.locProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.lanProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.titleProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx.disProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.facebookUrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.instaUrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.twitterUrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("color", ctx.variableColor);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx.variable, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx.buttonText, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
    } }, directives: [_header_of_deshboard_header_of_deshboard_component__WEBPACK_IMPORTED_MODULE_3__["HeaderOfDeshboardComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵangular_packages_forms_forms_x"], _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_5__["MainpageFooterComponent"]], styles: ["*[_ngcontent-%COMP%]{   font-family: 'Poppins', sans-serif;\r\n}\r\n.greeting[_ngcontent-%COMP%]{\r\n    text-align: center;\r\n}\r\n.greeting[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{\r\n    color: #008329;\r\n}\r\n.one[_ngcontent-%COMP%]{\r\n\r\n    \r\n    background-color:#F2F2F2;\r\n    color: black;\r\n    position: relative;\r\n    \r\n    padding: 5%;\r\n   \r\n}\r\n.two[_ngcontent-%COMP%]{\r\n    \r\n    \r\n    background-color: white;\r\n    position: relative;\r\n    text-align: center;\r\n    font-family: sans-serif;\r\n    align-items: center;\r\n    font-size: 30px;\r\n    \r\n    left: 50%; \r\n  \r\n    transform: translate(-50%);\r\n}\r\n.p1[_ngcontent-%COMP%]{\r\n    \r\n}\r\n.btn[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    background-color:#008329;\r\n}\r\n.p2[_ngcontent-%COMP%]{\r\n    margin-top: 100px;\r\n}\r\nlabel[_ngcontent-%COMP%]{\r\n    font-size: 25px;\r\n    padding-right: 20px;\r\n}\r\nselect[_ngcontent-%COMP%]{\r\n    \r\n    font-size: 20px;\r\n    width: 300px;\r\n    height: 40px;\r\n    padding-left: 30px;\r\n    border: 1px solid gray;\r\n    outline: none;\r\n}\r\ntextarea[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    width: 300px;\r\n\r\n    padding-left: 30px;\r\n    border: 1px solid gray;\r\n    outline: none;\r\n}\r\ninput[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    width: 300px;\r\n    height: 40px;\r\n    padding-left: 30px;\r\n    border: 1px solid gray;\r\n    outline: none;\r\n}\r\ntable[_ngcontent-%COMP%]{  \r\n    width: 100%;\r\n    position: relative;\r\n    left: 50%;\r\n    height: 200px;\r\n    margin-top: 4%;\r\n    margin-bottom: 4%;\r\n    transform: translate(-50%);\r\n    text-align: center;\r\n}\r\nform[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{\r\n    color: green;\r\n}\r\n.form-control.ng-touched.ng-invalid.ng-required[_ngcontent-%COMP%]{\r\n    border: 2px solid red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV2ZWxvcGVyLWRhc2gtYm9hcmQvZGV2ZWxvcGVyLWRhc2gtYm9hcmQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0EsS0FBSyxrQ0FBa0M7QUFDdkM7QUFDQTtJQUNJLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksY0FBYztBQUNsQjtBQUVBOztJQUVJLGtCQUFrQjtJQUNsQix3QkFBd0I7SUFDeEIsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQjt1QkFDbUI7SUFDbkIsV0FBVzs7QUFFZjtBQUNBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQix1QkFBdUI7SUFDdkIsa0JBQWtCO0lBQ2xCLGtCQUFrQjtJQUNsQix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLGVBQWU7SUFDZixhQUFhO0lBQ2IsU0FBUzs7SUFFVCwwQkFBMEI7QUFDOUI7QUFDQTs7QUFFQTtBQUNBO0lBQ0ksWUFBWTtJQUNaLHdCQUF3QjtBQUM1QjtBQUVBO0lBQ0ksaUJBQWlCO0FBQ3JCO0FBRUE7SUFDSSxlQUFlO0lBQ2YsbUJBQW1CO0FBQ3ZCO0FBRUE7SUFDSSw0QkFBNEI7SUFDNUIsZUFBZTtJQUNmLFlBQVk7SUFDWixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLHNCQUFzQjtJQUN0QixhQUFhO0FBQ2pCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsWUFBWTs7SUFFWixrQkFBa0I7SUFDbEIsc0JBQXNCO0lBQ3RCLGFBQWE7QUFDakI7QUFDQTtJQUNJLGVBQWU7SUFDZixZQUFZO0lBQ1osWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixzQkFBc0I7SUFDdEIsYUFBYTtBQUNqQjtBQUNBO0lBQ0ksV0FBVztJQUNYLGtCQUFrQjtJQUNsQixTQUFTO0lBQ1QsYUFBYTtJQUNiLGNBQWM7SUFDZCxpQkFBaUI7SUFDakIsMEJBQTBCO0lBQzFCLGtCQUFrQjtBQUN0QjtBQUVBO0lBQ0ksWUFBWTtBQUNoQjtBQUNBO0lBQ0kscUJBQXFCO0FBQ3pCIiwiZmlsZSI6InNyYy9hcHAvZGV2ZWxvcGVyLWRhc2gtYm9hcmQvZGV2ZWxvcGVyLWRhc2gtYm9hcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4qeyAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbn1cclxuLmdyZWV0aW5ne1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5ncmVldGluZyBzcGFue1xyXG4gICAgY29sb3I6ICMwMDgzMjk7XHJcbn1cclxuXHJcbi5vbmV7XHJcblxyXG4gICAgLyogaGVpZ2h0OiAxMDAlOyAqL1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjojRjJGMkYyO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgLyogbWFyZ2luLXRvcDo1JTtcclxuICAgIG1hcmdpbi1ib3R0b206NSU7ICovXHJcbiAgICBwYWRkaW5nOiA1JTtcclxuICAgXHJcbn1cclxuLnR3b3tcclxuICAgIC8qIHdpZHRoOiA1MCU7ICovXHJcbiAgICAvKiBoZWlnaHQ6IDEwMCU7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIC8qIHRvcDogNTAlOyovXHJcbiAgICBsZWZ0OiA1MCU7IFxyXG4gIFxyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XHJcbn1cclxuLnAxe1xyXG4gICAgXHJcbn1cclxuLmJ0bntcclxuICAgIHdpZHRoOiA0MDBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IzAwODMyOTtcclxufVxyXG5cclxuLnAye1xyXG4gICAgbWFyZ2luLXRvcDogMTAwcHg7XHJcbn1cclxuXHJcbmxhYmVse1xyXG4gICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMjBweDtcclxufVxyXG5cclxuc2VsZWN0e1xyXG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogZ3JheTsgKi9cclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMzBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbnRleHRhcmVhe1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG5cclxuICAgIHBhZGRpbmctbGVmdDogMzBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbmlucHV0e1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG4gICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgZ3JheTtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxudGFibGV7ICBcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIG1hcmdpbi10b3A6IDQlO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuZm9ybSBoNXtcclxuICAgIGNvbG9yOiBncmVlbjtcclxufVxyXG4uZm9ybS1jb250cm9sLm5nLXRvdWNoZWQubmctaW52YWxpZC5uZy1yZXF1aXJlZHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHJlZDtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DeveloperDashBoardComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-developer-dash-board',
                templateUrl: './developer-dash-board.component.html',
                styleUrls: ['./developer-dash-board.component.css']
            }]
    }], function () { return [{ type: _devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/devpofile/devpofile.component.ts":
/*!**************************************************!*\
  !*** ./src/app/devpofile/devpofile.component.ts ***!
  \**************************************************/
/*! exports provided: DevpofileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DevpofileComponent", function() { return DevpofileComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _devdata_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../devdata.service */ "./src/app/devdata.service.ts");
/* harmony import */ var _mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mainpage-header/mainpage-header.component */ "./src/app/mainpage-header/mainpage-header.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");





function DevpofileComponent_ul_69_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const i_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", i_r1, "");
} }
class DevpofileComponent {
    constructor(devs) {
        this.devs = devs;
        this.instaUrl = "";
    }
    ngOnInit() {
        var email = localStorage.getItem("devemail");
        this.devs.GetDevData().subscribe(res => {
            if (res.status = "ok") {
                res.data.forEach(element => {
                    if (element.email == email) {
                        this.id = element.id;
                        this.imgSource = "http://localhost:4000/" + element.email + "_profile.jpg";
                        this.emailProp = element.email;
                        this.nameProp = element.name[0].toUpperCase() + element.name.slice(1);
                        this.experienceProp = element.experience + " year";
                        this.degreeProp = element.degree.toUpperCase();
                        this.categoryProp = element.category[0].toUpperCase() + element.category.slice(1) + " Developer";
                        this.rateProp = element.rate + " $";
                        this.locProp = element.location[0].toUpperCase() + element.location.slice(1);
                        this.lanProp = element.category[0].toUpperCase() + element.category.slice(1);
                        this.titleProp = element.title[0].toUpperCase() + element.title.slice(1);
                        this.disProp = element.discription[0].toUpperCase() + element.discription.slice(1);
                        this.UnameProp = element.university.toUpperCase();
                        this.skillsArr = element.skills.split(",");
                        this.instaUrl = element.instaUrl;
                        this.facebookUrl = element.facebookUrl;
                        this.twitterUrl = element.twitterUrl;
                        console.log(this.emailProp, this.nameProp, this.experienceProp, this.degreeProp, this.categoryProp, this.id);
                    }
                });
            }
        });
        console.log(this.nameProp);
    }
    sendEmail() {
        // this.devs.save()
        this.devs.sendMail({ clientemail: this.clientemail, devemail: this.emailProp, emailsubject: this.emailsubject, emailcontent: this.emailcontent }).subscribe(res => {
            alert(res.err);
        });
        // , "ucvcxvuefudusgao" , "sumantv26@gmail.com", "this is just to Test Node mailer this is subject", `this is content   <h3>Hi</h3><br><h6>Following is the link to rest your password</h6><a href="http://localhost:4200/newpassword">Reset Password</a>` 
    }
}
DevpofileComponent.ɵfac = function DevpofileComponent_Factory(t) { return new (t || DevpofileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"])); };
DevpofileComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DevpofileComponent, selectors: [["app-devpofile"]], decls: 85, vars: 13, consts: [[1, "main-div"], [1, "center-div"], [1, "title-div"], [1, "img-div"], ["alt", "", 3, "src"], [1, "name-div"], [1, "main-location"], [1, "locicon"], ["aria-hidden", "true", 1, "fa", "fa-map-marker"], [1, "loctext"], [1, "center-bottom"], [1, "left-div"], [1, "stats"], [1, "row"], [1, "col"], [1, "available"], [1, "part-hr"], [1, "right-div"], [1, "right-div-title"], [1, "discription"], [1, "education"], [1, "skills"], [4, "ngFor", "ngForOf"], ["id", "contact-text"], [1, "email-id"], [1, "contact"], [1, "ainsta", 3, "href"], [1, "insta"], ["aria-hidden", "true", 1, "fa", "fa-instagram"], [3, "href"], [1, "facebook"], ["aria-hidden", "true", 1, "fa", "fa-facebook"], [1, "twitter"], ["aria-hidden", "true", 1, "fa", "fa-twitter"]], template: function DevpofileComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-mainpage-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Stats");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "0k");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "total earning");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](28, "0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Total Jobs");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](32, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](33, "0");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](34, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](35, "Total hour");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](38, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](39, "Availability");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](40, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](41, "Available");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](42, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](43, "More than 30 hrs/week ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](44, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](45, " < 24 hrs response time");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](46, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](48, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](51, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](52);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](53, "hr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](55, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](56, "Discription");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](57, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](58);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](60, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](61, "Education");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](62, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](63);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](64, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](65);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](66, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](67, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](68, "Skills");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](69, DevpofileComponent_ul_69_Template, 3, 1, "ul", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "h4", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](71, "Contact & Social media");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](73, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](74);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](76, "a", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](77, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](78, "i", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](79, "a", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](80, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](81, "i", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](82, "a", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](83, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](84, "i", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.imgSource, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.nameProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.locProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](36);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.titleProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.rateProp, " /hour");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.disProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("University: \u00A0 ", ctx.UnameProp, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Degree: \u00A0 ", ctx.degreeProp, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.skillsArr);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("Email: \u00A0 ", ctx.emailProp, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx.instaUrl, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx.facebookUrl, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx.twitterUrl, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    } }, directives: [_mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_2__["MainpageHeaderComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgForOf"]], styles: ["*[_ngcontent-%COMP%]{\r\n   \r\n   margin: 0;\r\n   padding: 0;\r\n   \r\n  \r\n}\r\n.main-location[_ngcontent-%COMP%]{\r\n    display: flex;\r\n}\r\n.locicon[_ngcontent-%COMP%]{\r\n    color: green;\r\npadding-bottom: 10px;\r\n    margin-left: 10px;\r\n    margin-right: 10px;\r\n   \r\n}\r\n.main-div[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    position: relative;\r\n    \r\n    margin-top: 2%;\r\n    background-color: #20a5ee;\r\n\r\n    \r\n}\r\n.center-div[_ngcontent-%COMP%]{\r\n    \r\n    font-family: 'Poppins', sans-serif;\r\n    \r\n    \r\n    margin-bottom: 50px;\r\n    padding: 20px;\r\n    width: 80%;\r\n    \r\n    position: absolute;\r\n    \r\n    \r\n    \r\n    left: 50%;\r\n    box-shadow: 0px 0px 20px 15px  gray;\r\n    border-radius: 20px;\r\n    transform: translate(-50%);\r\n    \r\n}\r\n.center-bottom[_ngcontent-%COMP%]{\r\n    display: flex;\r\n}\r\n.part-hr[_ngcontent-%COMP%]{\r\n    transform: rotate(180deg);\r\n\r\n    border-left: 2px solid gray;\r\n    \r\n\r\n}\r\n.title-div[_ngcontent-%COMP%]{\r\n    \r\n    width: 100%;\r\n    height: 100px;\r\n    display: flex;\r\n}\r\n.name-div[_ngcontent-%COMP%]{\r\n    margin: 10px;\r\n}\r\n.title-div[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{\r\n    \r\n\r\n    border-radius: 50%;\r\n    width: 70px;\r\n    height: 70px;\r\n}\r\n.left-div[_ngcontent-%COMP%]{\r\n  flex: 2;\r\n    width: 50%;\r\n    height: 100%;\r\n    padding: 10px;\r\n    \r\n}\r\n.right-div[_ngcontent-%COMP%]{\r\n    flex: 5;\r\n    width: 50%;\r\n    height: 100%;\r\n    \r\n}\r\n.right-div-title[_ngcontent-%COMP%]{\r\n    display: flex;\r\n}\r\n.right-div-title[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{\r\n    flex: 5;\r\n    padding-left: 50px;\r\n    \r\n}\r\n.right-div-title[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{\r\n   flex: 1;\r\n    \r\n    font-size: 25px;\r\n    margin: 10px;\r\n    \r\n}\r\n.discription[_ngcontent-%COMP%], .skills[_ngcontent-%COMP%], .education[_ngcontent-%COMP%]{\r\n    padding-left: 50px;\r\n    padding-top: 30px;\r\n}\r\n.discription[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-left: 10%;\r\n    font-size: 20px;\r\n    padding-top: 2%;\r\n}\r\n.education[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{\r\n    margin-left: 10%;\r\n    padding-top: 2%;\r\n}\r\n.contact[_ngcontent-%COMP%]{\r\n    display: flex;\r\n    font-family: 'Open Sans', sans-serif\r\n}\r\n.insta[_ngcontent-%COMP%], .facebook[_ngcontent-%COMP%], .twitter[_ngcontent-%COMP%]{\r\n    height: 50px;\r\n    width: 50px;\r\n    box-shadow: 0 0 10px gray;\r\n    border-radius: 30%;\r\n    margin-left: 20px;\r\n   \r\n    \r\n}\r\n.fa-instagram[_ngcontent-%COMP%]{\r\n    color:orange;\r\n    \r\n}\r\n.fa-facebook[_ngcontent-%COMP%]{\r\n    color:#3b5998\r\n}\r\n.fa-twitter[_ngcontent-%COMP%]{\r\n    color:#20a5ee\r\n}\r\n.fa[_ngcontent-%COMP%]{\r\n    position: relative;\r\n    font-size: 30px;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%,-50%);\r\n    \r\n}\r\n#contact-text[_ngcontent-%COMP%]{\r\n    padding-left: 50px;\r\n    padding-bottom: 20px;\r\n}\r\n.contact[_ngcontent-%COMP%]{\r\n    padding-left: 20px;\r\n    \r\n}\r\n.btn[_ngcontent-%COMP%]{\r\n    background-color: green;\r\n}\r\n.available[_ngcontent-%COMP%]{\r\n    margin-top: 10%;\r\n}\r\n.available[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{\r\n    margin-top: 5%;\r\n}\r\n.skills[_ngcontent-%COMP%]{\r\n    margin-bottom: 20px;\r\n}\r\n.skills[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{\r\n    padding: 5px;\r\n    margin-left: 10%;\r\n}\r\nh4[_ngcontent-%COMP%]{\r\n    color: #018328 ;\r\n}\r\n.send-email[_ngcontent-%COMP%]{\r\n    margin-top: 7%;\r\n   \r\n}\r\n.send-email[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]{\r\n    margin-top: 2%;\r\n    margin-bottom: 2%;\r\n}\r\n.email-id[_ngcontent-%COMP%]   h5[_ngcontent-%COMP%]{\r\n    margin-left: 6%;\r\n    margin-bottom: 5%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV2cG9maWxlL2RldnBvZmlsZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0dBQ0csMkJBQTJCO0dBQzNCLFNBQVM7R0FDVCxVQUFVO0dBQ1Ysa0JBQWtCOztBQUVyQjtBQUNBO0lBQ0ksYUFBYTtBQUNqQjtBQUNBO0lBQ0ksWUFBWTtBQUNoQixvQkFBb0I7SUFDaEIsaUJBQWlCO0lBQ2pCLGtCQUFrQjtHQUNuQixrQkFBa0I7QUFDckI7QUFFQTtJQUNJLGtDQUFrQztJQUNsQyxrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCx5QkFBeUI7O0lBRXpCLDRCQUE0QjtBQUNoQztBQUNBO0lBQ0ksc0JBQXNCO0lBQ3RCLGtDQUFrQztJQUNsQyw0QkFBNEI7SUFDNUIscUJBQXFCO0lBQ3JCLG1CQUFtQjtJQUNuQixhQUFhO0lBQ2IsVUFBVTtJQUNWLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIsMENBQTBDO0lBQzFDLG1CQUFtQjtJQUNuQixjQUFjO0lBQ2QsU0FBUztJQUNULG1DQUFtQztJQUNuQyxtQkFBbUI7SUFDbkIsMEJBQTBCO0lBQzFCLGtCQUFrQjtBQUN0QjtBQUVBO0lBQ0ksYUFBYTtBQUNqQjtBQUNBO0lBQ0kseUJBQXlCOztJQUV6QiwyQkFBMkI7OztBQUcvQjtBQUNBO0lBQ0ksNEJBQTRCO0lBQzVCLFdBQVc7SUFDWCxhQUFhO0lBQ2IsYUFBYTtBQUNqQjtBQUVBO0lBQ0ksWUFBWTtBQUNoQjtBQUNBO0lBQ0ksa0JBQWtCOztJQUVsQixrQkFBa0I7SUFDbEIsV0FBVztJQUNYLFlBQVk7QUFDaEI7QUFFQTtFQUNFLE9BQU87SUFDTCxVQUFVO0lBQ1YsWUFBWTtJQUNaLGFBQWE7SUFDYiw2QkFBNkI7QUFDakM7QUFDQTtJQUNJLE9BQU87SUFDUCxVQUFVO0lBQ1YsWUFBWTtJQUNaLGtDQUFrQztBQUN0QztBQUNBO0lBQ0ksYUFBYTtBQUNqQjtBQUNBO0lBQ0ksT0FBTztJQUNQLGtCQUFrQjtJQUNsQiwyQkFBMkI7QUFDL0I7QUFDQTtHQUNHLE9BQU87SUFDTixrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLFlBQVk7SUFDWixpQ0FBaUM7QUFDckM7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7QUFDckI7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixlQUFlO0lBQ2YsZUFBZTtBQUNuQjtBQUVBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGVBQWU7QUFDbkI7QUFFQTtJQUNJLGFBQWE7SUFDYjtBQUNKO0FBRUE7SUFDSSxZQUFZO0lBQ1osV0FBVztJQUNYLHlCQUF5QjtJQUN6QixrQkFBa0I7SUFDbEIsaUJBQWlCOztJQUVqQix3QkFBd0I7QUFDNUI7QUFDQTtJQUNJLFlBQVk7O0FBRWhCO0FBQ0E7SUFDSTtBQUNKO0FBQ0E7SUFDSTtBQUNKO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLFFBQVE7SUFDUixTQUFTO0lBQ1QsK0JBQStCOztBQUVuQztBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLG9CQUFvQjtBQUN4QjtBQUNBO0lBQ0ksa0JBQWtCOztBQUV0QjtBQUNBO0lBQ0ksdUJBQXVCO0FBQzNCO0FBQ0E7SUFDSSxlQUFlO0FBQ25CO0FBQ0E7SUFDSSxjQUFjO0FBQ2xCO0FBQ0E7SUFDSSxtQkFBbUI7QUFDdkI7QUFFQTtJQUNJLFlBQVk7SUFDWixnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLGVBQWU7QUFDbkI7QUFDQTtJQUNJLGNBQWM7O0FBRWxCO0FBQ0E7SUFDSSxjQUFjO0lBQ2QsaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0FBQ3JCIiwiZmlsZSI6InNyYy9hcHAvZGV2cG9maWxlL2RldnBvZmlsZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiKntcclxuICAgLyogYmFja2dyb3VuZC1jb2xvcjogcmVkOyAqL1xyXG4gICBtYXJnaW46IDA7XHJcbiAgIHBhZGRpbmc6IDA7XHJcbiAgIC8qIGhlaWdodDogMTAwJTsgKi9cclxuICBcclxufVxyXG4ubWFpbi1sb2NhdGlvbntcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLmxvY2ljb257XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbnBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgIC8qIG1hcmdpbjogMTBweDsgKi9cclxufVxyXG5cclxuLm1haW4tZGl2e1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8qIGhlaWdodDo5MDBweCA7ICovXHJcbiAgICBtYXJnaW4tdG9wOiAyJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyMGE1ZWU7XHJcblxyXG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogYmx1ZTsgKi9cclxufVxyXG4uY2VudGVyLWRpdntcclxuICAgIC8qIG92ZXJmbG93OiBzY3JvbGw7ICovXHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogYXF1YTsgKi9cclxuICAgIC8qIG1hcmdpbi10b3A6IDE1JTsgKi9cclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIC8qIGhlaWdodDogMTAwJTsgKi9cclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IHJnYigyMzMsIDIzMiwgMjMyKTsgKi9cclxuICAgIC8qIGhlaWdodDogMTAwcHg7ICovXHJcbiAgICAvKiB0b3A6IDQwJTsgKi9cclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMjBweCAxNXB4ICBncmF5O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUpO1xyXG4gICAgLyogZGlzcGxheTpmbGV4OyAqL1xyXG59XHJcblxyXG4uY2VudGVyLWJvdHRvbXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLnBhcnQtaHJ7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xyXG5cclxuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgZ3JheTtcclxuICAgIFxyXG5cclxufVxyXG4udGl0bGUtZGl2e1xyXG4gICAgLyogYmFja2dyb3VuZC1jb2xvcjogYXF1YTsgKi9cclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuXHJcbi5uYW1lLWRpdntcclxuICAgIG1hcmdpbjogMTBweDtcclxufVxyXG4udGl0bGUtZGl2IGltZ3tcclxuICAgIC8qIGhlaWdodDogNjBweDsgKi9cclxuXHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzBweDtcclxufVxyXG5cclxuLmxlZnQtZGl2e1xyXG4gIGZsZXg6IDI7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IGJyb3duOyAqL1xyXG59XHJcbi5yaWdodC1kaXZ7XHJcbiAgICBmbGV4OiA1O1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IGFxdWFtYXJpbmU7ICovXHJcbn1cclxuLnJpZ2h0LWRpdi10aXRsZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLnJpZ2h0LWRpdi10aXRsZSBoMXtcclxuICAgIGZsZXg6IDU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XHJcbiAgICAvKiBiYWNrZ3JvdW5kLWNvbG9yOiByZWQ7ICovXHJcbn1cclxuLnJpZ2h0LWRpdi10aXRsZSBoM3tcclxuICAgZmxleDogMTtcclxuICAgIC8qIGZsb2F0OiByaWdodDsgKi9cclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IHJveWFsYmx1ZTsgKi9cclxufVxyXG4uZGlzY3JpcHRpb24sLnNraWxscywuZWR1Y2F0aW9ue1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1MHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDMwcHg7XHJcbn1cclxuXHJcbi5kaXNjcmlwdGlvbiBwe1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwJTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHBhZGRpbmctdG9wOiAyJTtcclxufVxyXG5cclxuLmVkdWNhdGlvbiBoNXtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgICBwYWRkaW5nLXRvcDogMiU7XHJcbn0gXHJcblxyXG4uY29udGFjdHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmb250LWZhbWlseTogJ09wZW4gU2FucycsIHNhbnMtc2VyaWZcclxufVxyXG5cclxuLmluc3RhLC5mYWNlYm9vaywudHdpdHRlcntcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCAwIDEwcHggZ3JheTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICBcclxuICAgIC8qIHRleHQtYWxpZ246IGNlbnRlcjsgKi9cclxufVxyXG4uZmEtaW5zdGFncmFte1xyXG4gICAgY29sb3I6b3JhbmdlO1xyXG4gICAgXHJcbn1cclxuLmZhLWZhY2Vib29re1xyXG4gICAgY29sb3I6IzNiNTk5OFxyXG59XHJcbi5mYS10d2l0dGVye1xyXG4gICAgY29sb3I6IzIwYTVlZVxyXG59XHJcbi5mYXtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgIFxyXG59XHJcbiNjb250YWN0LXRleHR7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMjBweDtcclxufVxyXG4uY29udGFjdHtcclxuICAgIHBhZGRpbmctbGVmdDogMjBweDtcclxuICAgIFxyXG59XHJcbi5idG57XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcclxufVxyXG4uYXZhaWxhYmxle1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG59XHJcbi5hdmFpbGFibGUgaDV7XHJcbiAgICBtYXJnaW4tdG9wOiA1JTtcclxufVxyXG4uc2tpbGxze1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuLnNraWxscyB1bHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbn1cclxuaDR7XHJcbiAgICBjb2xvcjogIzAxODMyOCA7XHJcbn1cclxuLnNlbmQtZW1haWx7XHJcbiAgICBtYXJnaW4tdG9wOiA3JTtcclxuICAgXHJcbn1cclxuLnNlbmQtZW1haWwgLmZvcm0tZ3JvdXB7XHJcbiAgICBtYXJnaW4tdG9wOiAyJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDIlO1xyXG59XHJcbi5lbWFpbC1pZCBoNXtcclxuICAgIG1hcmdpbi1sZWZ0OiA2JTtcclxuICAgIG1hcmdpbi1ib3R0b206IDUlO1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](DevpofileComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-devpofile',
                templateUrl: './devpofile.component.html',
                styleUrls: ['./devpofile.component.css']
            }]
    }], function () { return [{ type: _devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/find-developers/find-developers.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/find-developers/find-developers.component.ts ***!
  \**************************************************************/
/*! exports provided: FindDevelopersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FindDevelopersComponent", function() { return FindDevelopersComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class FindDevelopersComponent {
    constructor() { }
    ngOnInit() {
    }
}
FindDevelopersComponent.ɵfac = function FindDevelopersComponent_Factory(t) { return new (t || FindDevelopersComponent)(); };
FindDevelopersComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FindDevelopersComponent, selectors: [["app-find-developers"]], decls: 2, vars: 0, template: function FindDevelopersComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "find-developers works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2ZpbmQtZGV2ZWxvcGVycy9maW5kLWRldmVsb3BlcnMuY29tcG9uZW50LmNzcyJ9 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FindDevelopersComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-find-developers',
                templateUrl: './find-developers.component.html',
                styleUrls: ['./find-developers.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/freelancers-by-skill/freelancers-by-skill.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/freelancers-by-skill/freelancers-by-skill.component.ts ***!
  \************************************************************************/
/*! exports provided: FreelancersBySkillComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FreelancersBySkillComponent", function() { return FreelancersBySkillComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class FreelancersBySkillComponent {
    constructor() { }
    ngOnInit() {
    }
}
FreelancersBySkillComponent.ɵfac = function FreelancersBySkillComponent_Factory(t) { return new (t || FreelancersBySkillComponent)(); };
FreelancersBySkillComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FreelancersBySkillComponent, selectors: [["app-freelancers-by-skill"]], decls: 2, vars: 0, template: function FreelancersBySkillComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "freelancers-by-skill works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2ZyZWVsYW5jZXJzLWJ5LXNraWxsL2ZyZWVsYW5jZXJzLWJ5LXNraWxsLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](FreelancersBySkillComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-freelancers-by-skill',
                templateUrl: './freelancers-by-skill.component.html',
                styleUrls: ['./freelancers-by-skill.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/header-of-deshboard/header-of-deshboard.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/header-of-deshboard/header-of-deshboard.component.ts ***!
  \**********************************************************************/
/*! exports provided: HeaderOfDeshboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderOfDeshboardComponent", function() { return HeaderOfDeshboardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class HeaderOfDeshboardComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    toggle() {
        var ul = document.getElementsByClassName("ul")[0];
        ul.setAttribute("display", "flex");
        alert("flex");
    }
    check(val) {
        localStorage.setItem("searchResult", val);
        this.router.navigate(['/searchResult']);
    }
    logout() {
        localStorage.setItem("login", "empty");
        this.router.navigate(["/mainpage/home"]);
    }
    gotoHome() {
        this.router.navigate(["/mainpage/home"]);
    }
}
HeaderOfDeshboardComponent.ɵfac = function HeaderOfDeshboardComponent_Factory(t) { return new (t || HeaderOfDeshboardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
HeaderOfDeshboardComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HeaderOfDeshboardComponent, selectors: [["app-header-of-deshboard"]], decls: 19, vars: 0, consts: [[1, "left-nav"], ["routerLink", "/mainpage/home", 1, "logo"], [2, "color", "#018328"], [1, "right-nav"], [1, "toggle-button", 3, "click"], [1, "bar"], [1, "item"], [1, "lnk", 3, "click"], [3, "click"]], template: function HeaderOfDeshboardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Free");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "lancing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderOfDeshboardComponent_Template_div_click_9_listener() { return ctx.toggle(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "ul", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "li", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderOfDeshboardComponent_Template_li_click_14_listener() { return ctx.gotoHome(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, "HOME");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function HeaderOfDeshboardComponent_Template_button_click_17_listener() { return ctx.logout(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18, "Logout");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"]], styles: ["*[_ngcontent-%COMP%]{\r\n    margin: 0px;\r\n    padding: 0px;\r\n    \r\n}\r\nheader[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    padding: 10px 5%;\r\n}\r\n.left-nav[_ngcontent-%COMP%]{\r\n}\r\n.logo[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\n.right-nav[_ngcontent-%COMP%]{\r\n    \r\n}\r\nul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n    display: inline-block;\r\n    margin-left: 10px ;\r\n   color: gray;\r\n}\r\n.lnk[_ngcontent-%COMP%]{\r\n    transition: all .5s ease;\r\n    outline: none;\r\n}\r\n.lnk[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 10px gray;\r\n    padding: 0px 10px;\r\n    border-radius: 10px;\r\n    color: white;\r\n    background-color: #018328;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    background-color: #018328;\r\n    color: white;\r\n    padding: 5px;\r\n    border: 0;\r\n    border-radius: 10px;\r\n    box-shadow: 5px 10px 10px #888888;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 5px  gray;\r\n    padding: 5px;\r\n    border-radius: 10px;\r\n}\r\n.toggle-button[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    display: none;\r\n    flex-direction: column;\r\n    justify-content: space-between;\r\n    right: 10%;\r\n    top:30px;\r\n    width: 30px;\r\n    height: 20px;\r\n\r\n}\r\n.toggle-button[_ngcontent-%COMP%]   .bar[_ngcontent-%COMP%]{\r\n    height: 4px;\r\n    width: 100%;\r\n    background-color: black;\r\n    border-radius: 10px;\r\n}\r\n@media all and (max-width:550px){\r\n    ul[_ngcontent-%COMP%]{\r\n        display: flex;\r\n        flex-direction: column;\r\n        width: 100%;\r\n    }\r\n    .toggle-button[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n    .right-nav[_ngcontent-%COMP%]{\r\n        width: 100%;\r\n    }\r\n    header[_ngcontent-%COMP%]{\r\n        flex-direction: column;\r\n        align-items: flex-start;\r\n    }\r\n  \r\n    ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n        text-align: center;\r\n        padding: 10px;\r\n    }\r\n    ul.active[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n\r\n    .lnk[_ngcontent-%COMP%]:hover{\r\n        background-color: #018328;\r\n        padding: 10px;\r\n        color: white;\r\n    }\r\n\r\n}\r\n\r\n.search-input[_ngcontent-%COMP%]{\r\n   \r\n    position: relative;\r\n}\r\n.search-icon[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    top: 10%;\r\n    left: 5px;\r\n    color:#018328;\r\n}\r\n.search-input[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{\r\n    padding-left: 25px;\r\n    border-radius: 50px;\r\n    border: 2px solid #018328;\r\n    outline: none;\r\n    width: 300px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyLW9mLWRlc2hib2FyZC9oZWFkZXItb2YtZGVzaGJvYXJkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTs7QUFFaEI7QUFDQTtJQUNJLGtDQUFrQztJQUNsQyxhQUFhO0lBQ2IsOEJBQThCO0lBQzlCLG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsZUFBZTtJQUNmLGFBQWE7QUFDakI7QUFDQTs7QUFFQTtBQUVBO0lBQ0kscUJBQXFCO0lBQ3JCLGtCQUFrQjtHQUNuQixXQUFXO0FBQ2Q7QUFDQTtJQUNJLHdCQUF3QjtJQUN4QixhQUFhO0FBQ2pCO0FBQ0E7SUFDSSw2QkFBNkI7SUFDN0IsaUJBQWlCO0lBQ2pCLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixhQUFhO0FBQ2pCO0FBRUE7SUFDSSxrQ0FBa0M7SUFDbEMseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixZQUFZO0lBQ1osU0FBUztJQUNULG1CQUFtQjtJQUNuQixpQ0FBaUM7SUFDakMsYUFBYTtBQUNqQjtBQUNBO0lBQ0ksNkJBQTZCO0lBQzdCLFlBQVk7SUFDWixtQkFBbUI7QUFDdkI7QUFHQTtJQUNJLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLDhCQUE4QjtJQUM5QixVQUFVO0lBQ1YsUUFBUTtJQUNSLFdBQVc7SUFDWCxZQUFZOztBQUVoQjtBQUVBO0lBQ0ksV0FBVztJQUNYLFdBQVc7SUFDWCx1QkFBdUI7SUFDdkIsbUJBQW1CO0FBQ3ZCO0FBRUE7SUFDSTtRQUNJLGFBQWE7UUFDYixzQkFBc0I7UUFDdEIsV0FBVztJQUNmO0lBQ0E7UUFDSSxhQUFhO0lBQ2pCO0lBQ0E7UUFDSSxXQUFXO0lBQ2Y7SUFDQTtRQUNJLHNCQUFzQjtRQUN0Qix1QkFBdUI7SUFDM0I7O0lBRUE7UUFDSSxrQkFBa0I7UUFDbEIsYUFBYTtJQUNqQjtJQUNBO1FBQ0ksYUFBYTtJQUNqQjs7SUFFQTtRQUNJLHlCQUF5QjtRQUN6QixhQUFhO1FBQ2IsWUFBWTtJQUNoQjs7QUFFSjtBQUVBLGVBQWU7QUFDZjs7SUFFSSxrQkFBa0I7QUFDdEI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixRQUFRO0lBQ1IsU0FBUztJQUNULGFBQWE7QUFDakI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIseUJBQXlCO0lBQ3pCLGFBQWE7SUFDYixZQUFZO0FBQ2hCO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F1REciLCJmaWxlIjoic3JjL2FwcC9oZWFkZXItb2YtZGVzaGJvYXJkL2hlYWRlci1vZi1kZXNoYm9hcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIip7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIHBhZGRpbmc6IDBweDtcclxuICAgIFxyXG59XHJcbmhlYWRlcntcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDEwcHggNSU7XHJcbn1cclxuLmxlZnQtbmF2e1xyXG59XHJcbi5sb2dve1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxufVxyXG4ucmlnaHQtbmF2e1xyXG4gICAgXHJcbn1cclxuXHJcbnVsIGxpe1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHggO1xyXG4gICBjb2xvcjogZ3JheTtcclxufVxyXG4ubG5re1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIC41cyBlYXNlO1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxufVxyXG4ubG5rOmhvdmVye1xyXG4gICAgYm94LXNoYWRvdzogNXB4IDVweCAxMHB4IGdyYXk7XHJcbiAgICBwYWRkaW5nOiAwcHggMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDE4MzI4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxufVxyXG5cclxuYnV0dG9ue1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMTgzMjg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBib3JkZXI6IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYm94LXNoYWRvdzogNXB4IDEwcHggMTBweCAjODg4ODg4O1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxufVxyXG5idXR0b246aG92ZXJ7XHJcbiAgICBib3gtc2hhZG93OiA1cHggNXB4IDVweCAgZ3JheTtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcblxyXG4udG9nZ2xlLWJ1dHRvbntcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgcmlnaHQ6IDEwJTtcclxuICAgIHRvcDozMHB4O1xyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcblxyXG59XHJcblxyXG4udG9nZ2xlLWJ1dHRvbiAuYmFye1xyXG4gICAgaGVpZ2h0OiA0cHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuQG1lZGlhIGFsbCBhbmQgKG1heC13aWR0aDo1NTBweCl7XHJcbiAgICB1bHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgICAudG9nZ2xlLWJ1dHRvbntcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgfVxyXG4gICAgLnJpZ2h0LW5hdntcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIGhlYWRlcntcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgfVxyXG4gIFxyXG4gICAgdWwgbGl7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB9XHJcbiAgICB1bC5hY3RpdmV7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgIH1cclxuXHJcbiAgICAubG5rOmhvdmVye1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwMTgzMjg7XHJcbiAgICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcblxyXG59XHJcblxyXG4vKiBzZWFyY2ggYmFyICovXHJcbi5zZWFyY2gtaW5wdXR7XHJcbiAgIFxyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcbi5zZWFyY2gtaWNvbntcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTAlO1xyXG4gICAgbGVmdDogNXB4O1xyXG4gICAgY29sb3I6IzAxODMyODtcclxufVxyXG4uc2VhcmNoLWlucHV0IGlucHV0e1xyXG4gICAgcGFkZGluZy1sZWZ0OiAyNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkICMwMTgzMjg7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG4vKlxyXG4ubGVmdC1uYXZ7XHJcblxyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgIFxyXG59XHJcbi5sb2dve1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuIFxyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDEwJTtcclxuICAgIFxyXG59XHJcbi5yaWdodC1uYXZ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBob3RwaW5rO1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgIFxyXG59XHJcblxyXG4vKiAuaGVhZGVyLWxpbmtze1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGFxdWFtYXJpbmU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgcmlnaHQ6IDEwJTtcclxuICAgXHJcbn0gXHJcbnVse1xyXG4gICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgYmFja2dyb3VuZC1jb2xvcjogZ3JleTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICByaWdodDogMTAlO1xyXG4gICAgXHJcbn1cclxudWwgbGl7XHJcbiAgICBib3JkZXI6ICAxcHggc29saWQgYmx1ZXZpb2xldDtcclxuICBcclxuICAgIHBhZGRpbmc6MTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICBcclxufSAqL1xyXG5cclxuIl19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](HeaderOfDeshboardComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-header-of-deshboard',
                templateUrl: './header-of-deshboard.component.html',
                styleUrls: ['./header-of-deshboard.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/loding-screen/loding-screen.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/loding-screen/loding-screen.component.ts ***!
  \**********************************************************/
/*! exports provided: LodingScreenComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LodingScreenComponent", function() { return LodingScreenComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class LodingScreenComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.gotologin();
    }
    gotologin() {
        setTimeout(() => {
            this.router.navigate(['/mainpage']);
        }, 3000);
    }
}
LodingScreenComponent.ɵfac = function LodingScreenComponent_Factory(t) { return new (t || LodingScreenComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
LodingScreenComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LodingScreenComponent, selectors: [["app-loding-screen"]], decls: 10, vars: 0, consts: [[1, "loadingio-spinner-bean-eater-41qg2z6vgpw", "icon"], [1, "ldio-258pjzb5efr"]], template: function LodingScreenComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["*[_ngcontent-%COMP%]{\r\n    position: relative;\r\n}\r\n\r\n.icon[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    left: 50%;\r\n    top: 50%;\r\n    transform: translate(-50%,-50%);\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9kaW5nLXNjcmVlbi9sb2Rpbmctc2NyZWVuLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsU0FBUztJQUNULFFBQVE7SUFDUiwrQkFBK0I7QUFDbkM7O0FBRUUseUJBQXlCOztBQUN6Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FrTUMiLCJmaWxlIjoic3JjL2FwcC9sb2Rpbmctc2NyZWVuL2xvZGluZy1zY3JlZW4uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIip7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5pY29ue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG59XHJcblxyXG4gIC8qIERFTU8tU1BFQ0lGSUMgU1RZTEVTICovXHJcbiAgLyogLmNzc2xvYWQtcHJlbG9hZGVyIHtcclxuXHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0dG9wOiAwcHg7XHJcblx0bGVmdDogMHB4O1xyXG5cdHJpZ2h0OiAwcHg7XHJcblx0Ym90dG9tOiAwcHg7XHJcblx0ei1pbmRleDogMTA7XHJcbn1cclxuXHJcbi5jc3Nsb2FkLXByZWxvYWRlciA+IC5jc3Nsb2FkLXByZWxvYWRlci1ib3gge1xyXG5cdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRoZWlnaHQ6IDI5cHg7XHJcblx0dG9wOiA1MCU7XHJcblx0bGVmdDogNTAlO1xyXG5cdG1hcmdpbjogLTE1cHggMCAwIC0xNDZweDtcclxuXHRwZXJzcGVjdGl2ZTogMTk1cHg7XHJcblx0XHQtby1wZXJzcGVjdGl2ZTogMTk1cHg7XHJcblx0XHQtbXMtcGVyc3BlY3RpdmU6IDE5NXB4O1xyXG5cdFx0LXdlYmtpdC1wZXJzcGVjdGl2ZTogMTk1cHg7XHJcblx0XHQtbW96LXBlcnNwZWN0aXZlOiAxOTVweDtcclxufVxyXG5cclxuLmNzc2xvYWQtcHJlbG9hZGVyIC5jc3Nsb2FkLXByZWxvYWRlci1ib3ggPiBkaXYge1xyXG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHR3aWR0aDogMjlweDtcclxuXHRoZWlnaHQ6IDI5cHg7XHJcblx0YmFja2dyb3VuZDogcmdiKDIwNCwyMDQsMjA0KTtcclxuXHRmbG9hdDogbGVmdDtcclxuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0bGluZS1oZWlnaHQ6IDI5cHg7XHJcblx0Zm9udC1mYW1pbHk6IFZlcmRhbmE7XHJcblx0Zm9udC1zaXplOiAxOXB4O1xyXG5cdGNvbG9yOiByZ2IoMjU1LDI1NSwyNTUpO1xyXG59LmNzc2xvYWQtcHJlbG9hZGVyIC5jc3Nsb2FkLXByZWxvYWRlci1ib3ggPiBkaXY6bnRoLWNoaWxkKDEpIHtcclxuXHRiYWNrZ3JvdW5kOiByZ2IoMTUsMjMwLDApO1xyXG5cdG1hcmdpbi1yaWdodDogMTVweDtcclxuXHRhbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAwbXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMG1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tcy1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAwbXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LXdlYmtpdC1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAwbXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAwbXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG59XHJcbi5jc3Nsb2FkLXByZWxvYWRlciAuY3NzbG9hZC1wcmVsb2FkZXItYm94ID4gZGl2Om50aC1jaGlsZCgyKSB7XHJcblx0YmFja2dyb3VuZDogcmdiKDIyLDIyNCw5Myk7XHJcblx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdGFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDg2LjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgODYuMjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbXMtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgODYuMjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDg2LjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA4Ni4yNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxufVxyXG4uY3NzbG9hZC1wcmVsb2FkZXIgLmNzc2xvYWQtcHJlbG9hZGVyLWJveCA+IGRpdjpudGgtY2hpbGQoMykge1xyXG5cdGJhY2tncm91bmQ6ICByZ2IoMTQsMjMyLDQ2KTtcclxuXHRtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcblx0YW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMTcyLjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtby1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAxNzIuNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tcy1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAxNzIuNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMTcyLjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbW96LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDE3Mi41bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG59XHJcbi5jc3Nsb2FkLXByZWxvYWRlciAuY3NzbG9hZC1wcmVsb2FkZXItYm94ID4gZGl2Om50aC1jaGlsZCg0KSB7XHJcblx0YmFja2dyb3VuZDogIHJnYigxNCwyMzIsNDYpO1xyXG5cdG1hcmdpbi1yaWdodDogMTVweDtcclxuXHRhbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAyNTguNzVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtby1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAyNTguNzVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbXMtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMjU4Ljc1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LXdlYmtpdC1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAyNTguNzVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbW96LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDI1OC43NW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxufVxyXG4uY3NzbG9hZC1wcmVsb2FkZXIgLmNzc2xvYWQtcHJlbG9hZGVyLWJveCA+IGRpdjpudGgtY2hpbGQoNSkge1xyXG5cdGJhY2tncm91bmQ6ICByZ2IoMTQsMjMyLDQ2KTtcclxuXHRtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcblx0YW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMzQ1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMzQ1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1zLWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDM0NW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgMzQ1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSAzNDVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcbn1cclxuLmNzc2xvYWQtcHJlbG9hZGVyIC5jc3Nsb2FkLXByZWxvYWRlci1ib3ggPiBkaXY6bnRoLWNoaWxkKDYpIHtcclxuXHRiYWNrZ3JvdW5kOiAgcmdiKDE0LDIzMiw0Nik7XHJcblx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdGFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDQzMS4yNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1vLWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDQzMS4yNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tcy1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA0MzEuMjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDQzMS4yNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tb3otYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNDMxLjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG59XHJcbi5jc3Nsb2FkLXByZWxvYWRlciAuY3NzbG9hZC1wcmVsb2FkZXItYm94ID4gZGl2Om50aC1jaGlsZCg3KSB7XHJcblx0YmFja2dyb3VuZDogcmdiKDE0LDIzMiw0Nik7XHJcblx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdGFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDUxNy41bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNTE3LjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbXMtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNTE3LjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDUxNy41bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA1MTcuNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxufVxyXG4uY3NzbG9hZC1wcmVsb2FkZXIgLmNzc2xvYWQtcHJlbG9hZGVyLWJveCA+IGRpdjpudGgtY2hpbGQoOCkge1xyXG5cdGJhY2tncm91bmQ6ICByZ2IoMTQsMjMyLDQ2KTtcclxuXHRtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcblx0YW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNjAzLjc1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNjAzLjc1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1zLWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDYwMy43NW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNjAzLjc1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA2MDMuNzVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcbn1cclxuLmNzc2xvYWQtcHJlbG9hZGVyIC5jc3Nsb2FkLXByZWxvYWRlci1ib3ggPiBkaXY6bnRoLWNoaWxkKDkpIHtcclxuXHRiYWNrZ3JvdW5kOiAgcmdiKDE0LDIzMiw0Nik7XHJcblx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdGFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDY5MG1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1vLWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDY5MG1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tcy1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA2OTBtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDY5MG1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC1tb3otYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNjkwbXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG59XHJcbi5jc3Nsb2FkLXByZWxvYWRlciAuY3NzbG9hZC1wcmVsb2FkZXItYm94ID4gZGl2Om50aC1jaGlsZCgxMCkge1xyXG5cdGJhY2tncm91bmQ6ICByZ2IoMTQsMjMyLDQ2KTtcclxuXHRtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcblx0YW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNzc2LjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNzc2LjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1zLWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDc3Ni4yNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgNzc2LjI1bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA3NzYuMjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcbn1cclxuLmNzc2xvYWQtcHJlbG9hZGVyIC5jc3Nsb2FkLXByZWxvYWRlci1ib3ggPiBkaXY6bnRoLWNoaWxkKDExKSB7XHJcblx0YmFja2dyb3VuZDogcmdiKDE0LDIzMiw0Nik7XHJcblx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdGFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDg2Mi41bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgODYyLjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtbXMtYW5pbWF0aW9uOiBjc3Nsb2FkLW1vdmVtZW50IDY5MG1zIGVhc2UgODYyLjVtcyBpbmZpbml0ZSBhbHRlcm5hdGU7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbjogY3NzbG9hZC1tb3ZlbWVudCA2OTBtcyBlYXNlIDg2Mi41bXMgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb246IGNzc2xvYWQtbW92ZW1lbnQgNjkwbXMgZWFzZSA4NjIuNW1zIGluZmluaXRlIGFsdGVybmF0ZTtcclxufVxyXG5cclxuXHJcbkBrZXlmcmFtZXMgY3NzbG9hZC1tb3ZlbWVudCB7XHJcblx0ZnJvbSB7XHJcblx0XHR0cmFuc2Zvcm06IHNjYWxlKDEuMCkgdHJhbnNsYXRlWSgwcHgpIHJvdGF0ZVgoMGRlZyk7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMCAwIDAgcGluaztcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcblx0fVxyXG5cdHRvIHtcclxuXHRcdHRyYW5zZm9ybTogc2NhbGUoMS41KSB0cmFuc2xhdGVZKC0yNHB4KSByb3RhdGVYKDQ1ZGVnKTtcclxuXHRcdGJveC1zaGFkb3c6IDAgMjRweCAzOXB4IHJnYigxNCwyMzIsNDYpO1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHdoZWF0O1xyXG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuXHR9XHJcbn1cclxuXHJcbkAtby1rZXlmcmFtZXMgY3NzbG9hZC1tb3ZlbWVudCB7XHJcblx0ZnJvbSB7XHJcblx0XHQtby10cmFuc2Zvcm06IHNjYWxlKDEuMCkgdHJhbnNsYXRlWSgwcHgpIHJvdGF0ZVgoMGRlZyk7XHJcblx0XHRib3gtc2hhZG93OiAwIDAgMCByZ2JhKDAsMCwwLDApO1xyXG5cdH1cclxuXHR0byB7XHJcblx0XHQtby10cmFuc2Zvcm06IHNjYWxlKDEuNSkgdHJhbnNsYXRlWSgtMjRweCkgcm90YXRlWCg0NWRlZyk7XHJcblx0XHRib3gtc2hhZG93OiAwIDI0cHggMzlweCByZ2IoMTQsMjMyLDQ2KTtcclxuXHRcdGJhY2tncm91bmQ6IHJnYigwLDAsMCk7XHJcblx0fVxyXG59XHJcblxyXG5ALW1zLWtleWZyYW1lcyBjc3Nsb2FkLW1vdmVtZW50IHtcclxuXHRmcm9tIHtcclxuXHRcdC1tcy10cmFuc2Zvcm06IHNjYWxlKDEuMCkgdHJhbnNsYXRlWSgwcHgpIHJvdGF0ZVgoMGRlZyk7XHJcblx0XHRib3gtc2hhZG93OiAwIDAgMCByZ2JhKDAsMCwwLDApO1xyXG5cdH1cclxuXHR0byB7XHJcblx0XHQtbXMtdHJhbnNmb3JtOiBzY2FsZSgxLjUpIHRyYW5zbGF0ZVkoLTI0cHgpIHJvdGF0ZVgoNDVkZWcpO1xyXG5cdFx0Ym94LXNoYWRvdzogMCAyNHB4IDM5cHggcmdiKDE0LDIzMiw0Nik7XHJcblx0XHRiYWNrZ3JvdW5kOiByZ2IoMCwwLDApO1xyXG5cdH1cclxufVxyXG5cclxuQC13ZWJraXQta2V5ZnJhbWVzIGNzc2xvYWQtbW92ZW1lbnQge1xyXG5cdGZyb20ge1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEuMCkgdHJhbnNsYXRlWSgwcHgpIHJvdGF0ZVgoMGRlZyk7XHJcblx0XHRib3gtc2hhZG93OiAwIDAgMCByZ2JhKDAsMCwwLDApO1xyXG5cdH1cclxuXHR0byB7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMS41KSB0cmFuc2xhdGVZKC0yNHB4KSByb3RhdGVYKDQ1ZGVnKTtcclxuXHRcdGJveC1zaGFkb3c6IDAgMjRweCAzOXB4IHJnYigxNCwyMzIsNDYpO1xyXG5cdFx0YmFja2dyb3VuZDogcmdiKDAsMCwwKTtcclxuXHR9XHJcbn1cclxuXHJcbkAtbW96LWtleWZyYW1lcyBjc3Nsb2FkLW1vdmVtZW50IHtcclxuXHRmcm9tIHtcclxuXHRcdC1tb3otdHJhbnNmb3JtOiBzY2FsZSgxLjApIHRyYW5zbGF0ZVkoMHB4KSByb3RhdGVYKDBkZWcpO1xyXG5cdFx0Ym94LXNoYWRvdzogMCAwIDAgcmdiYSgwLDAsMCwwKTtcclxuXHR9XHJcblx0dG8ge1xyXG5cdFx0LW1vei10cmFuc2Zvcm06IHNjYWxlKDEuNSkgdHJhbnNsYXRlWSgtMjRweCkgcm90YXRlWCg0NWRlZyk7XHJcblx0XHRib3gtc2hhZG93OiAwIDI0cHggMzlweCByZ2IoMTQsMjMyLDQ2KTtcclxuXHRcdGJhY2tncm91bmQ6IHJnYigwLDAsMCk7XHJcblx0fVxyXG59ICovIl19 */", "@keyframes ldio-258pjzb5efr-1 {\n        0% { transform: rotate(0deg) }\n       50% { transform: rotate(-45deg) }\n      100% { transform: rotate(0deg) }\n    }\n    @keyframes ldio-258pjzb5efr-2 {\n        0% { transform: rotate(180deg) }\n       50% { transform: rotate(225deg) }\n      100% { transform: rotate(180deg) }\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(2) {\n      transform: translate(-15px,0);\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(2)   div[_ngcontent-%COMP%] {\n      position: absolute;\n      top: 40px;\n      left: 40px;\n      width: 120px;\n      height: 60px;\n      border-radius: 120px 120px 0 0;\n      background: #f8b26a;\n      animation: ldio-258pjzb5efr-1 1s linear infinite;\n      transform-origin: 60px 60px\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(2)   div[_ngcontent-%COMP%]:nth-child(2) {\n      animation: ldio-258pjzb5efr-2 1s linear infinite\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(2)   div[_ngcontent-%COMP%]:nth-child(3) {\n      transform: rotate(-90deg);\n      animation: none;\n    }@keyframes ldio-258pjzb5efr-3 {\n        0% { transform: translate(190px,0); opacity: 0 }\n       20% { opacity: 1 }\n      100% { transform: translate(70px,0); opacity: 1 }\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(1) {\n      display: block;\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(1)   div[_ngcontent-%COMP%] {\n      position: absolute;\n      top: 92px;\n      left: -8px;\n      width: 16px;\n      height: 16px;\n      border-radius: 50%;\n      background: #e15b64;\n      animation: ldio-258pjzb5efr-3 1s linear infinite\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(1)   div[_ngcontent-%COMP%]:nth-child(1) { animation-delay: -0.67s }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(1)   div[_ngcontent-%COMP%]:nth-child(2) { animation-delay: -0.33s }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]    > div[_ngcontent-%COMP%]:nth-child(1)   div[_ngcontent-%COMP%]:nth-child(3) { animation-delay: 0s }\n    .loadingio-spinner-bean-eater-41qg2z6vgpw[_ngcontent-%COMP%] {\n      width: 200px;\n      height: 200px;\n      display: inline-block;\n      overflow: hidden;\n      background: #ffffff;\n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%] {\n      width: 100%;\n      height: 100%;\n      position: relative;\n      transform: translateZ(0) scale(1);\n      backface-visibility: hidden;\n      transform-origin: 0 0; \n    }\n    .ldio-258pjzb5efr[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] { box-sizing: content-box; }"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LodingScreenComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-loding-screen',
                templateUrl: './loding-screen.component.html',
                styleUrls: ['./loding-screen.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");






function LoginComponent_span_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this is a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function LoginComponent_div_10_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Enter vaild email");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function LoginComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, LoginComponent_div_10_span_1_Template, 2, 0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.touched && _r1.errors.pattern);
} }
function LoginComponent_div_14_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function LoginComponent_div_14_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" minimum length should be ", _r4.errors.minlength.requiredLength, " charcters ");
} }
function LoginComponent_div_14_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "at least one letter, one number and one special character");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function LoginComponent_div_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, LoginComponent_div_14_span_1_Template, 2, 0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, LoginComponent_div_14_span_2_Template, 2, 1, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, LoginComponent_div_14_span_3_Template, 2, 0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.required);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.minlength);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.pattern);
} }
class LoginComponent {
    constructor(router, ds) {
        this.router = router;
        this.ds = ds;
        this.acFound = false;
        this.emailProp = "";
        this.passwordProp = "";
        this.details = [];
    }
    ngOnInit() {
    }
    signin() {
        var acFound = false;
        if (this.emailProp != "" && this.passwordProp != "") {
            // {email:this.emailProp, password:this.passwordProp}
            this.ds.signIn({})
                .subscribe((response) => {
                if (response.status == "ok") {
                    // localStorage.setItem('email', this.emailProp);
                    // localStorage.setItem('name', response.data[0].name);
                    // this.data=response.data[0].password
                    response.data.forEach(element => {
                        // this.details.push(element.name)
                        // console.log(element.email,element.password)
                        if (element.email == this.emailProp && element.password == this.passwordProp) {
                            acFound = true;
                            console.log(element.email, element.password);
                            localStorage.setItem('email', element.email);
                            localStorage.setItem('name', element.name);
                            localStorage.setItem("login", element.name);
                            this.router.navigate(['/dev-dashboard']);
                        }
                    });
                }
                if (acFound == false) {
                    alert("somthing went wrong");
                }
            });
        }
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 22, vars: 6, consts: [[1, "one"], [1, "two"], [1, "p1"], ["ngNativeValidate", ""], ["userForm", "ngForm"], [1, "form-group"], ["type", "email", "name", "email", "placeholder", "Email", "id", "email", "pattern", "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$", "required", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["emailRef", "ngModel"], [4, "ngIf"], ["type", "password", "name", "pwd", "placeholder", "Password", "id", "pwd", "required", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["passRef", "ngModel"], ["type", "submit", 1, "btn", "btn-success", 3, "disabled", "click"], [1, "p2"], ["routerLink", "/mainpage/signup", "type", "submit", "id", "signup", 1, "btn", "btn-success"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Log in and get to work ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "form", 3, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 6, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_7_listener($event) { return ctx.emailProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, LoginComponent_span_9_Template, 2, 0, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, LoginComponent_div_10_Template, 2, 1, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "input", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function LoginComponent_Template_input_ngModelChange_12_listener($event) { return ctx.passwordProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, LoginComponent_div_14_Template, 4, 3, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_15_listener() { return ctx.signin(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Continue");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "p", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "New User");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Sign Up");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](5);
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](8);
        const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.emailProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.touched && _r1.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.passwordProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", _r0.form.invalid);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["PatternValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"]], styles: ["*[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n}\r\n.one[_ngcontent-%COMP%]{\r\n\r\n    height: 100%;\r\n    background-color:#F2F2F2;\r\n    color: black;\r\n    position: relative;\r\n    padding: 5%;\r\n   \r\n}\r\n.two[_ngcontent-%COMP%]{\r\n    width: 550px;\r\n    \r\n    background-color: white;\r\n    position: relative;\r\n    text-align: center;\r\n    font-family: sans-serif;\r\n    font-size: 30px;\r\n    \r\n    left: 50%;\r\n    transform: translate(-50%);\r\n    padding-top: 5%;\r\n    padding-bottom: 5%;\r\n}\r\n.p1[_ngcontent-%COMP%]{\r\n    \r\n}\r\n.btn[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    background-color:#008329;\r\n}\r\n#email[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n#pwd[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n.p2[_ngcontent-%COMP%]{\r\n    margin-top: 4%;\r\n    font-size: 25px;\r\n}\r\n#signup[_ngcontent-%COMP%]{\r\n    background-color: white;\r\n    color: green;\r\n}\r\nspan[_ngcontent-%COMP%]{\r\n    color: red;\r\n    font-size: 15px;\r\n}\r\n.form-control.ng-touched.ng-invalid[_ngcontent-%COMP%]{\r\n    border: 2px solid red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtDQUFrQztBQUN0QztBQUNBOztJQUVJLFlBQVk7SUFDWix3QkFBd0I7SUFDeEIsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixXQUFXOztBQUVmO0FBQ0E7SUFDSSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLHVCQUF1QjtJQUN2QixrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLHVCQUF1QjtJQUN2QixlQUFlO0lBQ2YsY0FBYztJQUNkLFNBQVM7SUFDVCwwQkFBMEI7SUFDMUIsZUFBZTtJQUNmLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksc0JBQXNCO0FBQzFCO0FBQ0E7SUFDSSxZQUFZO0lBQ1osd0JBQXdCO0FBQzVCO0FBQ0E7SUFDSSxZQUFZO0lBQ1osaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxZQUFZO0lBQ1osaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjtBQUNBO0lBQ0ksdUJBQXVCO0lBQ3ZCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLFVBQVU7SUFDVixlQUFlO0FBQ25CO0FBRUE7SUFDSSxxQkFBcUI7QUFDekIiLCJmaWxlIjoic3JjL2FwcC9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiKntcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbn1cclxuLm9uZXtcclxuXHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiNGMkYyRjI7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBwYWRkaW5nOiA1JTtcclxuICAgXHJcbn1cclxuLnR3b3tcclxuICAgIHdpZHRoOiA1NTBweDtcclxuICAgIC8qIGhlaWdodDogNTAwcHg7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgLyogdG9wOiA1MCU7ICovXHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcclxuICAgIHBhZGRpbmctdG9wOiA1JTtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1JTtcclxufVxyXG4ucDF7XHJcbiAgICAvKiBtYXJnaW4tdG9wOiA1MHB4OyAqL1xyXG59XHJcbi5idG57XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMwMDgzMjk7XHJcbn1cclxuI2VtYWlse1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDc1cHg7XHJcbn1cclxuI3B3ZHtcclxuICAgIHdpZHRoOiA0MDBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA3NXB4O1xyXG59XHJcbi5wMntcclxuICAgIG1hcmdpbi10b3A6IDQlO1xyXG4gICAgZm9udC1zaXplOiAyNXB4O1xyXG59XHJcbiNzaWdudXB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGNvbG9yOiBncmVlbjtcclxufVxyXG5zcGFue1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbC5uZy10b3VjaGVkLm5nLWludmFsaWR7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](LoginComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-login',
                templateUrl: './login.component.html',
                styleUrls: ['./login.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }, { type: _data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/main-page/main-page.component.ts":
/*!**************************************************!*\
  !*** ./src/app/main-page/main-page.component.ts ***!
  \**************************************************/
/*! exports provided: MainPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPageComponent", function() { return MainPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../mainpage-header/mainpage-header.component */ "./src/app/mainpage-header/mainpage-header.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../mainpage-footer/mainpage-footer.component */ "./src/app/mainpage-footer/mainpage-footer.component.ts");





class MainPageComponent {
    constructor() { }
    ngOnInit() {
    }
}
MainPageComponent.ɵfac = function MainPageComponent_Factory(t) { return new (t || MainPageComponent)(); };
MainPageComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainPageComponent, selectors: [["app-main-page"]], decls: 3, vars: 0, template: function MainPageComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-mainpage-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-mainpage-footer");
    } }, directives: [_mainpage_header_mainpage_header_component__WEBPACK_IMPORTED_MODULE_1__["MainpageHeaderComponent"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"], _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_3__["MainpageFooterComponent"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21haW4tcGFnZS9tYWluLXBhZ2UuY29tcG9uZW50LmNzcyJ9 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MainPageComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-main-page',
                templateUrl: './main-page.component.html',
                styleUrls: ['./main-page.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/mainpage-footer/mainpage-footer.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/mainpage-footer/mainpage-footer.component.ts ***!
  \**************************************************************/
/*! exports provided: MainpageFooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainpageFooterComponent", function() { return MainpageFooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class MainpageFooterComponent {
    constructor() { }
    ngOnInit() {
    }
}
MainpageFooterComponent.ɵfac = function MainpageFooterComponent_Factory(t) { return new (t || MainpageFooterComponent)(); };
MainpageFooterComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainpageFooterComponent, selectors: [["app-mainpage-footer"]], decls: 33, vars: 0, consts: [[1, "footer-container"], [1, "heading"], [1, "line1"], [1, "part-div"], [1, "company"], ["routerLink", "/mainpage/aboutUs"], ["routerLink", "/mainpage/termsOfService"], ["routerLink", "/mainpage/privacyPolicy"], ["routerLink", "/mainpage/accessibility"], [1, "resources"], ["routerLink", "/mainpage/resources"], ["routerLink", "/mainpage/customerSupport"], ["routerLink", "/mainpage/customerStories"], ["routerLink", "/mainpage/businessResources"], [1, "browse"], ["routerLink", "/searchResult"]], template: function MainpageFooterComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Looking to hire for long-term or full-time assignments?");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "hr", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "COMPANY");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "About Us");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "p", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "Terms of Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "p", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Privacy Policy");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "p", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, "Accessibility");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](19, "RESOURCES");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](20, "p", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](21, "Resources");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "p", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](23, "Customer Support");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "p", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Customer Stories");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "Business Resources");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](28, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "BROWSE");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "p", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](32, "Find Developers");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"]], styles: [".footer-container[_ngcontent-%COMP%]{\r\n    \r\n    background-color:#1D4354;\r\n}\r\n\r\n.part-div[_ngcontent-%COMP%]{\r\n    display: flex;\r\n}\r\n\r\n.heading[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    color: white;\r\n    font-weight: lighter;\r\n    text-align: center;\r\n}\r\n\r\n.line1[_ngcontent-%COMP%]{\r\n    background-color: white;\r\n    \r\n}\r\n\r\n.company[_ngcontent-%COMP%]{\r\n    flex: 1;\r\n    color: white;\r\n    \r\n    \r\n    background-color:#1D4354;\r\n    text-align: center;\r\n}\r\n\r\n.resources[_ngcontent-%COMP%]{\r\n    flex: 1;\r\n    color: white;\r\n    \r\n    \r\n    background-color:#1D4354;\r\n    position: relative;\r\n    \r\n    text-align: center;\r\n}\r\n\r\n.browse[_ngcontent-%COMP%]{\r\n    flex: 1;\r\n    color: white;\r\n    \r\n    \r\n    background-color:#1D4354;\r\n    position: relative;\r\n    \r\n    \r\n    text-align: center;\r\n}\r\n\r\np[_ngcontent-%COMP%]{\r\n    outline: none;\r\n    cursor: pointer;\r\n}\r\n\r\n.form-control.ng-touched.ng-invalid[_ngcontent-%COMP%]{\r\n    border: 2px solid red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbnBhZ2UtZm9vdGVyL21haW5wYWdlLWZvb3Rlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0lBQ25CLHdCQUF3QjtBQUM1Qjs7QUFFQTtJQUNJLGFBQWE7QUFDakI7O0FBQ0E7SUFDSSxlQUFlO0lBQ2YsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixrQkFBa0I7QUFDdEI7O0FBQ0E7SUFDSSx1QkFBdUI7SUFDdkIsZ0JBQWdCO0FBQ3BCOztBQUNBO0lBQ0ksT0FBTztJQUNQLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsZ0JBQWdCO0lBQ2hCLHdCQUF3QjtJQUN4QixrQkFBa0I7QUFDdEI7O0FBQ0E7SUFDSSxPQUFPO0lBQ1AsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsd0JBQXdCO0lBQ3hCLGtCQUFrQjtJQUNsQjtrQkFDYztJQUNkLGtCQUFrQjtBQUN0Qjs7QUFDQTtJQUNJLE9BQU87SUFDUCxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLGdCQUFnQjtJQUNoQix3QkFBd0I7SUFDeEIsa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsa0JBQWtCO0FBQ3RCOztBQUNBO0lBQ0ksYUFBYTtJQUNiLGVBQWU7QUFDbkI7O0FBQ0E7SUFDSSxxQkFBcUI7QUFDekIiLCJmaWxlIjoic3JjL2FwcC9tYWlucGFnZS1mb290ZXIvbWFpbnBhZ2UtZm9vdGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZm9vdGVyLWNvbnRhaW5lcntcclxuICAgIC8qIGhlaWdodDogMjAwcHg7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMxRDQzNTQ7XHJcbn1cclxuXHJcbi5wYXJ0LWRpdntcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuLmhlYWRpbmd7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXdlaWdodDogbGlnaHRlcjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4ubGluZTF7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIC8qIHdpZHRoOiA5MCU7ICovXHJcbn1cclxuLmNvbXBhbnl7XHJcbiAgICBmbGV4OiAxO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgLyogaGVpZ2h0OiAyNzBweDsgKi9cclxuICAgIC8qIHdpZHRoOiAzMSU7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMxRDQzNTQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLnJlc291cmNlc3tcclxuICAgIGZsZXg6IDE7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAvKiBoZWlnaHQ6IDI3MHB4OyAqL1xyXG4gICAgLyogd2lkdGg6IDMxJTsgKi9cclxuICAgIGJhY2tncm91bmQtY29sb3I6IzFENDM1NDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8qIGxlZnQ6IDMyJTtcclxuICAgIHRvcDogLTI3MHB4OyAqL1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5icm93c2V7XHJcbiAgICBmbGV4OiAxO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgLyogaGVpZ2h0OiAyNzBweDsgKi9cclxuICAgIC8qIHdpZHRoOiAzMSU7ICovXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMxRDQzNTQ7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAvKiBsZWZ0OjY0JTsgKi9cclxuICAgIC8qIHRvcDotNTQwcHg7ICovXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxucHtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmZvcm0tY29udHJvbC5uZy10b3VjaGVkLm5nLWludmFsaWR7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbn0iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MainpageFooterComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-mainpage-footer',
                templateUrl: './mainpage-footer.component.html',
                styleUrls: ['./mainpage-footer.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/mainpage-header/mainpage-header.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/mainpage-header/mainpage-header.component.ts ***!
  \**************************************************************/
/*! exports provided: MainpageHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainpageHeaderComponent", function() { return MainpageHeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");




function MainpageHeaderComponent_li_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "li");
} }
function MainpageHeaderComponent_ng_template_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "SIGN IN");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "SIGN UP");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function MainpageHeaderComponent_ng_template_26_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHeaderComponent_ng_template_26_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r6.gotoDeshboard(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r5.currentUser);
} }
class MainpageHeaderComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
        this.currentUser = localStorage.getItem("login")[0].toUpperCase() + localStorage.getItem("login").slice(1);
        console.log(this.currentUser);
    }
    toggle() {
        var ul = document.getElementsByClassName("ul")[0];
        ul.setAttribute("display", "flex");
        alert("flex");
    }
    check(val) {
        localStorage.setItem("searchResult", val);
        this.router.navigate(['/searchResult']);
    }
    gotoDeshboard() {
        this.router.navigate(["dev-dashboard"]);
        console.log(this.currentUser);
    }
}
MainpageHeaderComponent.ɵfac = function MainpageHeaderComponent_Factory(t) { return new (t || MainpageHeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
MainpageHeaderComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainpageHeaderComponent, selectors: [["app-mainpage-header"]], decls: 28, vars: 3, consts: [[1, "left-nav"], ["routerLink", "/mainpage/home", 1, "logo"], [2, "color", "#018328"], [1, "search-input"], ["type", "text", 3, "keyup.enter"], ["box", ""], [1, "search-icon"], [1, "fa", "fa-search"], [1, "right-nav"], [1, "toggle-button", 3, "click"], [1, "bar"], [1, "item"], ["routerLink", "/mainpage/home", 1, "lnk"], ["routerLink", "/mainpage/contact", 1, "lnk"], [4, "ngIf", "ngIfThen", "ngIfElse"], ["login", ""], ["logout", ""], ["routerLink", "/mainpage/signin", 1, "lnk"], ["routerLink", "/mainpage/signup"], ["title", "click here for Deshboard", 1, "lnk", 3, "click"]], template: function MainpageHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Free");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "lancing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "input", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function MainpageHeaderComponent_Template_input_keyup_enter_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10); return ctx.check(_r0.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHeaderComponent_Template_div_click_14_listener() { return ctx.toggle(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "ul", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "li", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "HOME");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "li", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "CONTACT");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](23, MainpageHeaderComponent_li_23_Template, 1, 0, "li", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, MainpageHeaderComponent_ng_template_24_Template, 5, 0, "ng-template", null, 15, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](26, MainpageHeaderComponent_ng_template_26_Template, 2, 1, "ng-template", null, 16, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](25);
        const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.currentUser == "Empty")("ngIfThen", _r2)("ngIfElse", _r4);
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"]], styles: ["*[_ngcontent-%COMP%]{\r\n    margin: 0px;\r\n    padding: 0px;\r\n    \r\n}\r\nheader[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    padding: 10px 5%;\r\n    box-shadow: 0 0 20px gray;\r\n}\r\n.left-nav[_ngcontent-%COMP%]{\r\n}\r\n.logo[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\n.right-nav[_ngcontent-%COMP%]{\r\n    \r\n}\r\nul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n    display: inline-block;\r\n    margin-left: 10px ;\r\n   color: gray;\r\n}\r\n.lnk[_ngcontent-%COMP%]{\r\n    transition: all .5s ease;\r\n    outline: none;\r\n}\r\n.lnk[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 10px gray;\r\n    padding: 0px 10px;\r\n    border-radius: 10px;\r\n    color: white;\r\n    background-color: #018328;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    background-color: #018328;\r\n    color: white;\r\n    padding: 5px;\r\n    border: 0;\r\n    border-radius: 10px;\r\n    box-shadow: 5px 10px 10px #888888;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 5px  gray;\r\n    padding: 5px;\r\n    border-radius: 10px;\r\n}\r\n.toggle-button[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    display: none;\r\n    flex-direction: column;\r\n    justify-content: space-between;\r\n    right: 10%;\r\n    top:30px;\r\n    width: 30px;\r\n    height: 20px;\r\n\r\n}\r\n.toggle-button[_ngcontent-%COMP%]   .bar[_ngcontent-%COMP%]{\r\n    height: 4px;\r\n    width: 100%;\r\n    background-color: black;\r\n    border-radius: 10px;\r\n}\r\n@media all and (max-width:550px){\r\n    ul[_ngcontent-%COMP%]{\r\n        display: flex;\r\n        flex-direction: column;\r\n        width: 100%;\r\n    }\r\n    .toggle-button[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n    .right-nav[_ngcontent-%COMP%]{\r\n        width: 100%;\r\n    }\r\n    header[_ngcontent-%COMP%]{\r\n        flex-direction: column;\r\n        align-items: flex-start;\r\n    }\r\n  \r\n    ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n        text-align: center;\r\n        padding: 10px;\r\n    }\r\n    ul.active[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n\r\n    .lnk[_ngcontent-%COMP%]:hover{\r\n        background-color: #018328;\r\n        padding: 10px;\r\n        color: white;\r\n    }\r\n\r\n}\r\n\r\n.search-input[_ngcontent-%COMP%]{\r\n   \r\n    position: relative;\r\n}\r\n.search-icon[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    top: 10%;\r\n    left: 5px;\r\n    color:#018328;\r\n}\r\n.search-input[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{\r\n    padding-left: 25px;\r\n    border-radius: 50px;\r\n    border: 2px solid #018328;\r\n    outline: none;\r\n    width: 300px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbnBhZ2UtaGVhZGVyL21haW5wYWdlLWhlYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLFlBQVk7O0FBRWhCO0FBQ0E7SUFDSSxrQ0FBa0M7SUFDbEMsYUFBYTtJQUNiLDhCQUE4QjtJQUM5QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0lBQ2hCLHlCQUF5QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtJQUNJLGVBQWU7SUFDZixlQUFlO0lBQ2YsYUFBYTtBQUNqQjtBQUNBOztBQUVBO0FBRUE7SUFDSSxxQkFBcUI7SUFDckIsa0JBQWtCO0dBQ25CLFdBQVc7QUFDZDtBQUNBO0lBQ0ksd0JBQXdCO0lBQ3hCLGFBQWE7QUFDakI7QUFDQTtJQUNJLDZCQUE2QjtJQUM3QixpQkFBaUI7SUFDakIsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsZUFBZTtJQUNmLGFBQWE7QUFDakI7QUFFQTtJQUNJLGtDQUFrQztJQUNsQyx5QkFBeUI7SUFDekIsWUFBWTtJQUNaLFlBQVk7SUFDWixTQUFTO0lBQ1QsbUJBQW1CO0lBQ25CLGlDQUFpQztJQUNqQyxhQUFhO0FBQ2pCO0FBQ0E7SUFDSSw2QkFBNkI7SUFDN0IsWUFBWTtJQUNaLG1CQUFtQjtBQUN2QjtBQUdBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsOEJBQThCO0lBQzlCLFVBQVU7SUFDVixRQUFRO0lBQ1IsV0FBVztJQUNYLFlBQVk7O0FBRWhCO0FBRUE7SUFDSSxXQUFXO0lBQ1gsV0FBVztJQUNYLHVCQUF1QjtJQUN2QixtQkFBbUI7QUFDdkI7QUFFQTtJQUNJO1FBQ0ksYUFBYTtRQUNiLHNCQUFzQjtRQUN0QixXQUFXO0lBQ2Y7SUFDQTtRQUNJLGFBQWE7SUFDakI7SUFDQTtRQUNJLFdBQVc7SUFDZjtJQUNBO1FBQ0ksc0JBQXNCO1FBQ3RCLHVCQUF1QjtJQUMzQjs7SUFFQTtRQUNJLGtCQUFrQjtRQUNsQixhQUFhO0lBQ2pCO0lBQ0E7UUFDSSxhQUFhO0lBQ2pCOztJQUVBO1FBQ0kseUJBQXlCO1FBQ3pCLGFBQWE7UUFDYixZQUFZO0lBQ2hCOztBQUVKO0FBRUEsZUFBZTtBQUNmOztJQUVJLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixTQUFTO0lBQ1QsYUFBYTtBQUNqQjtBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsYUFBYTtJQUNiLFlBQVk7QUFDaEI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXVERyIsImZpbGUiOiJzcmMvYXBwL21haW5wYWdlLWhlYWRlci9tYWlucGFnZS1oZWFkZXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIip7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIHBhZGRpbmc6IDBweDtcclxuICAgIFxyXG59XHJcbmhlYWRlcntcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDEwcHggNSU7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgMjBweCBncmF5O1xyXG59XHJcbi5sZWZ0LW5hdntcclxufVxyXG4ubG9nb3tcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLnJpZ2h0LW5hdntcclxuICAgIFxyXG59XHJcblxyXG51bCBsaXtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4IDtcclxuICAgY29sb3I6IGdyYXk7XHJcbn1cclxuLmxua3tcclxuICAgIHRyYW5zaXRpb246IGFsbCAuNXMgZWFzZTtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuLmxuazpob3ZlcntcclxuICAgIGJveC1zaGFkb3c6IDVweCA1cHggMTBweCBncmF5O1xyXG4gICAgcGFkZGluZzogMHB4IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAxODMyODtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuXHJcbmJ1dHRvbntcclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDE4MzI4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gICAgYm9yZGVyOiAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJveC1zaGFkb3c6IDVweCAxMHB4IDEwcHggIzg4ODg4ODtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbn1cclxuYnV0dG9uOmhvdmVye1xyXG4gICAgYm94LXNoYWRvdzogNXB4IDVweCA1cHggIGdyYXk7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcblxyXG5cclxuLnRvZ2dsZS1idXR0b257XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIHJpZ2h0OiAxMCU7XHJcbiAgICB0b3A6MzBweDtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG5cclxufVxyXG5cclxuLnRvZ2dsZS1idXR0b24gLmJhcntcclxuICAgIGhlaWdodDogNHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbkBtZWRpYSBhbGwgYW5kIChtYXgtd2lkdGg6NTUwcHgpe1xyXG4gICAgdWx7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgLnRvZ2dsZS1idXR0b257XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgIH1cclxuICAgIC5yaWdodC1uYXZ7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcbiAgICBoZWFkZXJ7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgIH1cclxuICBcclxuICAgIHVsIGxpe1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgfVxyXG4gICAgdWwuYWN0aXZle1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB9XHJcblxyXG4gICAgLmxuazpob3ZlcntcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDE4MzI4O1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuLyogc2VhcmNoIGJhciAqL1xyXG4uc2VhcmNoLWlucHV0e1xyXG4gICBcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG4uc2VhcmNoLWljb257XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwJTtcclxuICAgIGxlZnQ6IDVweDtcclxuICAgIGNvbG9yOiMwMTgzMjg7XHJcbn1cclxuLnNlYXJjaC1pbnB1dCBpbnB1dHtcclxuICAgIHBhZGRpbmctbGVmdDogMjVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjMDE4MzI4O1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICAgIHdpZHRoOiAzMDBweDtcclxufVxyXG5cclxuLypcclxuLmxlZnQtbmF2e1xyXG5cclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICBcclxufVxyXG4ubG9nb3tcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiBcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiAxMCU7XHJcbiAgICBcclxufVxyXG4ucmlnaHQtbmF2e1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogaG90cGluaztcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICBcclxufVxyXG5cclxuLyogLmhlYWRlci1saW5rc3tcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBhcXVhbWFyaW5lO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHJpZ2h0OiAxMCU7XHJcbiAgIFxyXG59IFxyXG51bHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgIGJhY2tncm91bmQtY29sb3I6IGdyZXk7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgcmlnaHQ6IDEwJTtcclxuICAgIFxyXG59XHJcbnVsIGxpe1xyXG4gICAgYm9yZGVyOiAgMXB4IHNvbGlkIGJsdWV2aW9sZXQ7XHJcbiAgXHJcbiAgICBwYWRkaW5nOjEwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgXHJcbn0gKi9cclxuXHJcbiJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MainpageHeaderComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-mainpage-header',
                templateUrl: './mainpage-header.component.html',
                styleUrls: ['./mainpage-header.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/mainpage-home/mainpage-home.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/mainpage-home/mainpage-home.component.ts ***!
  \**********************************************************/
/*! exports provided: MainpageHomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainpageHomeComponent", function() { return MainpageHomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _searchinteraction_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../searchinteraction.service */ "./src/app/searchinteraction.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




class MainpageHomeComponent {
    constructor(interaction, router) {
        this.interaction = interaction;
        this.router = router;
    }
    ngOnInit() {
    }
    sendMsg(val) {
        this.interaction.sendSearchValue("web");
        localStorage.setItem("searchResult", val);
        this.router.navigate(['/searchResult']);
    }
}
MainpageHomeComponent.ɵfac = function MainpageHomeComponent_Factory(t) { return new (t || MainpageHomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_searchinteraction_service__WEBPACK_IMPORTED_MODULE_1__["SearchinteractionService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"])); };
MainpageHomeComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: MainpageHomeComponent, selectors: [["app-mainpage-home"]], decls: 78, vars: 0, consts: [[1, "main-container"], [1, "img-container"], [1, "img-text", "animate__animated", "animate__backInLeft"], ["routerLink", "/mainpage/signup", 1, "getstarted-btn"], ["src", "../../assets/component.png", "alt", "", 1, "animate__animated", "animate__backInDown", "img"], ["src", "../../assets/free.png", "alt", "", 1, "imgAboveCardContainer"], [1, "divOnImage"], [1, "card-container"], [1, "cards"], [1, "item", 3, "click"], ["src", "../../assets/web.svg", "alt", ""], ["src", "../../assets/writing.svg", "alt", ""], ["src", "../../assets/design&creative.svg", "alt", ""], ["src", "../../assets/engAndArch.svg", "alt", ""], ["src", "../../assets/datascience.svg", "alt", ""], ["src", "../../assets/salesAndMarketing.svg", "alt", ""], [1, "lineBelowCardContainer"], [1, "divBelowCardContainer"], [1, "register"], ["src", "../../assets/reg.svg", "alt", "", 1, "registerImg"], [1, "collaborate"], ["src", "../../assets/collab.svg", "alt", "", 1, "collabImg"], [1, "payment"], ["src", "../../assets/pay.svg", "alt", "", 1, "payImg"]], template: function MainpageHomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "Get ready to Work :)");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "Get your talent & ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " Put your talent");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Expertly connects professionals and agencies to");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, "businesses seeking specialized talent.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, "Get Started");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "You can find any");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, " developer here.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](24, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](25, "Find quality talent or agencies");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](27, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_27_listener() { return ctx.sendMsg("web android apple fullstack software"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](28, "img", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](29, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](30, "Web, Mobile & Software Dev");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](31, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_31_listener() { return ctx.sendMsg("writing"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](32, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](33, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](34, "Writing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](35, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_35_listener() { return ctx.sendMsg("designing creative"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](36, "img", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](37, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](38, "Designing & Creative");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](39, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_39_listener() { return ctx.sendMsg("engineering architecture"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](40, "img", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](41, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](42, "Engineering & Architecture");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](43, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_43_listener() { return ctx.sendMsg("dataScience"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](44, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](45, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](46, "Data Science & Analytics");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](47, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MainpageHomeComponent_Template_div_click_47_listener() { return ctx.sendMsg("marketing"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](48, "img", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](49, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](50, "Sales & Marketing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](51, "hr", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](52, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](53, " How it works ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](54, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](55, "img", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](56, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](57, "Register yourself");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](58, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](59, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](60, "Developers first register yourself(SignUp) Then SignIn and fill your details.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](61, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](62, " Clients visit our website , search developer and contact. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](63, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](64, "img", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](65, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](66, "Collaborate easily");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](67, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](68, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](69, "Use freelancing to chat or video call, share files, and track project milestones from your desktop or mobile.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](70, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](71, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](72, "h5");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](73, "Payment simplified");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](74, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](75, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](76, "Pay hourly or fixed-price and receive invoices through Upwork. Pay for work you authorize..");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](77, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLink"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]], styles: ["*[_ngcontent-%COMP%]{\r\n margin: 0;\r\n padding:0 ;\r\n font-family: 'Poppins', sans-serif;\r\n\r\n}\r\n.main-container[_ngcontent-%COMP%]{\r\n    \r\n}\r\n.img-container[_ngcontent-%COMP%]{\r\n    position: relative;\r\n    height: 300px;\r\n    box-sizing: border-box;\r\n    \r\n}\r\n.img[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    right: 10%;\r\n    top: 10%;\r\n    height: 200px;\r\n}\r\n.img-text[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    transform: translateY(-100%);\r\n    top: 25%;\r\n    left: 10%;\r\n    color: #018328;\r\n}\r\n.img-text[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    color: gray;\r\n}\r\n.getstarted-btn[_ngcontent-%COMP%]{\r\n    background-color:#018328 ;\r\n    color: aliceblue;\r\n    margin-top: 5px;\r\n    border:0;\r\n    font-size: 15px;\r\n    padding: 8px;\r\n    outline: none;\r\n}\r\n.getstarted-btn[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 5px gray;\r\n}\r\n\r\n.card-container[_ngcontent-%COMP%]{\r\n    position: relative;\r\n    height: 500px;\r\n}\r\n.card-container[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{\r\n    text-align: center;\r\n    padding-top: 10px;\r\n}\r\n.cards[_ngcontent-%COMP%]{\r\n    padding-top: 50px;\r\n    display: grid;\r\n    grid-template-columns: auto auto auto;\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%,-50%);\r\n    gap: 20px;\r\n   \r\n}\r\n.item[_ngcontent-%COMP%]{\r\n    box-shadow: 5px 5px 10px 5px gray;\r\n    height: 200px;\r\n    width: 280px;\r\n    text-align: center;\r\n    transition: 1s;\r\n}\r\n.item[_ngcontent-%COMP%]   h6[_ngcontent-%COMP%]{\r\n    padding-top: 20px;\r\n}\r\n.item[_ngcontent-%COMP%]:hover{\r\n    transform: scale(1.1);\r\n}\r\n.imgAboveCardContainer[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 400px;\r\n}\r\n.divOnImage[_ngcontent-%COMP%]{\r\n    width: 52%;\r\n    height:390px;\r\n    background-color: #1B4153;\r\n    position:absolute;\r\n    top:360px;\r\n    left:0px;\r\n    color: white;\r\n    font-size: 60px;\r\n    font-weight:bold;\r\n    font-family: sans-serif;\r\n    font-style: initial ;\r\n    text-align: center;\r\n}\r\n.divOnImage[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{\r\n    color: #6FDA44;\r\n}\r\n.lineBelowCardContainer[_ngcontent-%COMP%]{\r\n    color:black;\r\n}\r\n.divBelowCardContainer[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 400px;\r\n    font-size: 35px;\r\n    font-weight: bold;\r\n    text-align: center;\r\n    margin-top: 20px;\r\n}\r\n.register[_ngcontent-%COMP%]{\r\n    color:black;\r\n    height: 330px;\r\n    width: 33.33%;\r\n    background-color:white;\r\n    margin-top: 10px;\r\n    text-align: center;\r\n}\r\n.collaborate[_ngcontent-%COMP%]{\r\n    color:black;\r\n    height: 330px;\r\n    width: 33.33%;\r\n    background-color:white;\r\n    margin-top: 10px;\r\n    text-align: center;\r\n    position: relative;\r\n    left: 33%;\r\n    top: -340px;\r\n}\r\n.payment[_ngcontent-%COMP%]{\r\n    color:black;\r\n    height: 330px;\r\n    width: 33.33%;\r\n    background-color:white;\r\n    margin-top: 10px;\r\n    text-align: center;\r\n    position: relative;\r\n    left: 66%;\r\n    top: -680px;\r\n}\r\n.registerImg[_ngcontent-%COMP%]{\r\n    width: 30%;\r\n    height: 30%;\r\n}\r\n.collabImg[_ngcontent-%COMP%]{\r\n    width: 30%;\r\n    height: 30%;\r\n}\r\n.payImg[_ngcontent-%COMP%]{\r\n    width: 30%;\r\n    height: 30%;\r\n}\r\n@media all and (max-width:750px){\r\n    .img[_ngcontent-%COMP%]{\r\n        width: 40%;\r\n    }\r\n    .img-text[_ngcontent-%COMP%]{\r\n        width: 50%;\r\n        left: 5%;\r\n        top: 5%;\r\n        overflow: hidden;\r\n    }\r\n    .img-container[_ngcontent-%COMP%]{\r\n        position: relative;\r\n        height: 300px;\r\n        box-sizing: border-box;\r\n    \r\n    }\r\n    .card-container[_ngcontent-%COMP%]{\r\n        height: 800px;\r\n    }\r\n    .cards[_ngcontent-%COMP%]{\r\n        grid-template-columns: auto auto;\r\n    }\r\n}\r\n@media all and (max-width:550px){\r\n    .card-container[_ngcontent-%COMP%]{\r\n        height: 1400px;\r\n    }\r\n    .cards[_ngcontent-%COMP%]{\r\n        grid-template-columns: auto;\r\n    }\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFpbnBhZ2UtaG9tZS9tYWlucGFnZS1ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Q0FDQyxTQUFTO0NBQ1QsVUFBVTtDQUNWLGtDQUFrQzs7QUFFbkM7QUFDQTs7QUFFQTtBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixzQkFBc0I7O0FBRTFCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFFBQVE7SUFDUixhQUFhO0FBQ2pCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsNEJBQTRCO0lBQzVCLFFBQVE7SUFDUixTQUFTO0lBQ1QsY0FBYztBQUNsQjtBQUVBO0lBQ0ksV0FBVztBQUNmO0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsZ0JBQWdCO0lBQ2hCLGVBQWU7SUFDZixRQUFRO0lBQ1IsZUFBZTtJQUNmLFlBQVk7SUFDWixhQUFhO0FBQ2pCO0FBQ0E7SUFDSSw0QkFBNEI7QUFDaEM7QUFFQSxVQUFVO0FBQ1Y7SUFDSSxrQkFBa0I7SUFDbEIsYUFBYTtBQUNqQjtBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGlCQUFpQjtBQUNyQjtBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYixxQ0FBcUM7SUFDckMsa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixTQUFTO0lBQ1QsK0JBQStCO0lBQy9CLFNBQVM7O0FBRWI7QUFDQTtJQUNJLGlDQUFpQztJQUNqQyxhQUFhO0lBQ2IsWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixjQUFjO0FBQ2xCO0FBQ0E7SUFDSSxpQkFBaUI7QUFDckI7QUFFQTtJQUNJLHFCQUFxQjtBQUN6QjtBQUNBO0lBQ0ksV0FBVztJQUNYLGFBQWE7QUFDakI7QUFDQTtJQUNJLFVBQVU7SUFDVixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLGlCQUFpQjtJQUNqQixTQUFTO0lBQ1QsUUFBUTtJQUNSLFlBQVk7SUFDWixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHVCQUF1QjtJQUN2QixvQkFBb0I7SUFDcEIsa0JBQWtCO0FBQ3RCO0FBQ0E7SUFDSSxjQUFjO0FBQ2xCO0FBQ0E7SUFDSSxXQUFXO0FBQ2Y7QUFDQTtJQUNJLFdBQVc7SUFDWCxhQUFhO0lBQ2IsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSxXQUFXO0lBQ1gsYUFBYTtJQUNiLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtBQUN0QjtBQUNBO0lBQ0ksV0FBVztJQUNYLGFBQWE7SUFDYixhQUFhO0lBQ2Isc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCxXQUFXO0FBQ2Y7QUFDQTtJQUNJLFdBQVc7SUFDWCxhQUFhO0lBQ2IsYUFBYTtJQUNiLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLGtCQUFrQjtJQUNsQixTQUFTO0lBQ1QsV0FBVztBQUNmO0FBQ0E7SUFDSSxVQUFVO0lBQ1YsV0FBVztBQUNmO0FBQ0E7SUFDSSxVQUFVO0lBQ1YsV0FBVztBQUNmO0FBQ0E7SUFDSSxVQUFVO0lBQ1YsV0FBVztBQUNmO0FBQ0E7SUFDSTtRQUNJLFVBQVU7SUFDZDtJQUNBO1FBQ0ksVUFBVTtRQUNWLFFBQVE7UUFDUixPQUFPO1FBQ1AsZ0JBQWdCO0lBQ3BCO0lBQ0E7UUFDSSxrQkFBa0I7UUFDbEIsYUFBYTtRQUNiLHNCQUFzQjs7SUFFMUI7SUFDQTtRQUNJLGFBQWE7SUFDakI7SUFDQTtRQUNJLGdDQUFnQztJQUNwQztBQUNKO0FBQ0E7SUFDSTtRQUNJLGNBQWM7SUFDbEI7SUFDQTtRQUNJLDJCQUEyQjtJQUMvQjtBQUNKIiwiZmlsZSI6InNyYy9hcHAvbWFpbnBhZ2UtaG9tZS9tYWlucGFnZS1ob21lLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqe1xyXG4gbWFyZ2luOiAwO1xyXG4gcGFkZGluZzowIDtcclxuIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcblxyXG59XHJcbi5tYWluLWNvbnRhaW5lcntcclxuICAgIFxyXG59XHJcbi5pbWctY29udGFpbmVye1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgaGVpZ2h0OiAzMDBweDtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBcclxufVxyXG4uaW1ne1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDEwJTtcclxuICAgIHRvcDogMTAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxufSBcclxuLmltZy10ZXh0e1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xMDAlKTtcclxuICAgIHRvcDogMjUlO1xyXG4gICAgbGVmdDogMTAlO1xyXG4gICAgY29sb3I6ICMwMTgzMjg7XHJcbn1cclxuXHJcbi5pbWctdGV4dCBwe1xyXG4gICAgY29sb3I6IGdyYXk7XHJcbn1cclxuXHJcbi5nZXRzdGFydGVkLWJ0bntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IzAxODMyOCA7XHJcbiAgICBjb2xvcjogYWxpY2VibHVlO1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgYm9yZGVyOjA7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbi5nZXRzdGFydGVkLWJ0bjpob3ZlcntcclxuICAgIGJveC1zaGFkb3c6IDVweCA1cHggNXB4IGdyYXk7XHJcbn1cclxuXHJcbi8qIGNhcmRzICovXHJcbi5jYXJkLWNvbnRhaW5lcntcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGhlaWdodDogNTAwcHg7XHJcbn1cclxuXHJcbi5jYXJkLWNvbnRhaW5lciBoM3tcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uY2FyZHN7XHJcbiAgICBwYWRkaW5nLXRvcDogNTBweDtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IGF1dG8gYXV0byBhdXRvO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgZ2FwOiAyMHB4O1xyXG4gICBcclxufVxyXG4uaXRlbXtcclxuICAgIGJveC1zaGFkb3c6IDVweCA1cHggMTBweCA1cHggZ3JheTtcclxuICAgIGhlaWdodDogMjAwcHg7XHJcbiAgICB3aWR0aDogMjgwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB0cmFuc2l0aW9uOiAxcztcclxufVxyXG4uaXRlbSBoNntcclxuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xyXG59XHJcblxyXG4uaXRlbTpob3ZlcntcclxuICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xKTtcclxufVxyXG4uaW1nQWJvdmVDYXJkQ29udGFpbmVye1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQwMHB4O1xyXG59XHJcbi5kaXZPbkltYWdle1xyXG4gICAgd2lkdGg6IDUyJTtcclxuICAgIGhlaWdodDozOTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMxQjQxNTM7XHJcbiAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgIHRvcDozNjBweDtcclxuICAgIGxlZnQ6MHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiA2MHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6Ym9sZDtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zdHlsZTogaW5pdGlhbCA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmRpdk9uSW1hZ2Ugc3BhbntcclxuICAgIGNvbG9yOiAjNkZEQTQ0O1xyXG59XHJcbi5saW5lQmVsb3dDYXJkQ29udGFpbmVye1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbn1cclxuLmRpdkJlbG93Q2FyZENvbnRhaW5lcntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0MDBweDtcclxuICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxufVxyXG4ucmVnaXN0ZXJ7XHJcbiAgICBjb2xvcjpibGFjaztcclxuICAgIGhlaWdodDogMzMwcHg7XHJcbiAgICB3aWR0aDogMzMuMzMlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjp3aGl0ZTtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmNvbGxhYm9yYXRle1xyXG4gICAgY29sb3I6YmxhY2s7XHJcbiAgICBoZWlnaHQ6IDMzMHB4O1xyXG4gICAgd2lkdGg6IDMzLjMzJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6d2hpdGU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogMzMlO1xyXG4gICAgdG9wOiAtMzQwcHg7XHJcbn1cclxuLnBheW1lbnR7XHJcbiAgICBjb2xvcjpibGFjaztcclxuICAgIGhlaWdodDogMzMwcHg7XHJcbiAgICB3aWR0aDogMzMuMzMlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjp3aGl0ZTtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBsZWZ0OiA2NiU7XHJcbiAgICB0b3A6IC02ODBweDtcclxufVxyXG4ucmVnaXN0ZXJJbWd7XHJcbiAgICB3aWR0aDogMzAlO1xyXG4gICAgaGVpZ2h0OiAzMCU7XHJcbn1cclxuLmNvbGxhYkltZ3tcclxuICAgIHdpZHRoOiAzMCU7XHJcbiAgICBoZWlnaHQ6IDMwJTtcclxufVxyXG4ucGF5SW1ne1xyXG4gICAgd2lkdGg6IDMwJTtcclxuICAgIGhlaWdodDogMzAlO1xyXG59XHJcbkBtZWRpYSBhbGwgYW5kIChtYXgtd2lkdGg6NzUwcHgpe1xyXG4gICAgLmltZ3tcclxuICAgICAgICB3aWR0aDogNDAlO1xyXG4gICAgfVxyXG4gICAgLmltZy10ZXh0e1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgbGVmdDogNSU7XHJcbiAgICAgICAgdG9wOiA1JTtcclxuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgfVxyXG4gICAgLmltZy1jb250YWluZXJ7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIGhlaWdodDogMzAwcHg7XHJcbiAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIFxyXG4gICAgfVxyXG4gICAgLmNhcmQtY29udGFpbmVye1xyXG4gICAgICAgIGhlaWdodDogODAwcHg7XHJcbiAgICB9XHJcbiAgICAuY2FyZHN7XHJcbiAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvIGF1dG87XHJcbiAgICB9XHJcbn1cclxuQG1lZGlhIGFsbCBhbmQgKG1heC13aWR0aDo1NTBweCl7XHJcbiAgICAuY2FyZC1jb250YWluZXJ7XHJcbiAgICAgICAgaGVpZ2h0OiAxNDAwcHg7XHJcbiAgICB9XHJcbiAgICAuY2FyZHN7XHJcbiAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBhdXRvO1xyXG4gICAgfVxyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](MainpageHomeComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-mainpage-home',
                templateUrl: './mainpage-home.component.html',
                styleUrls: ['./mainpage-home.component.css']
            }]
    }], function () { return [{ type: _searchinteraction_service__WEBPACK_IMPORTED_MODULE_1__["SearchinteractionService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/privacy-policy/privacy-policy.component.ts":
/*!************************************************************!*\
  !*** ./src/app/privacy-policy/privacy-policy.component.ts ***!
  \************************************************************/
/*! exports provided: PrivacyPolicyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyComponent", function() { return PrivacyPolicyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class PrivacyPolicyComponent {
    constructor() { }
    ngOnInit() {
    }
}
PrivacyPolicyComponent.ɵfac = function PrivacyPolicyComponent_Factory(t) { return new (t || PrivacyPolicyComponent)(); };
PrivacyPolicyComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: PrivacyPolicyComponent, selectors: [["app-privacy-policy"]], decls: 7, vars: 0, consts: [[1, "PPDetails"]], template: function PrivacyPolicyComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Privacy Policy");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " Freelancing Global Inc. (\u201CFreelancing\u201D) provides this Privacy Policy to let you know our policies and procedures regarding the collection, use and disclosure of information through www.freelancing.com (the \u201CSite\u201D), and any other websites, features, applications, widgets or online services that are owned or controlled by Freelancing and that post a link to this Privacy Policy (together with the Site, the \u201CService\u201D), as well as any information Freelancing collects offline in connection with the Service. It also describes the choices available to you regarding the use of, your access to, and how to update and correct your personal information. This Privacy Policy incorporates by reference the Freelancing Global Data Processing Agreement. Note that we combine the information we collect from you from the Site, through the Service generally, or offline.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " We\u2019ve provided short summaries in this Privacy Policy to help you understand what information we collect, how we use it, and what choices or rights you may have. While these summaries help explain some of these concepts in a simple and clear way, we encourage you to read the entire Privacy Policy to understand our data practices.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".PPDetails[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: white;\r\n    color: black;\r\n}\r\n.PPDetails[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n    font-weight: bolder;\r\n    color: black;\r\n    margin-left: 30px;\r\n}\r\n.PPDetails[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-left: 30px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJpdmFjeS1wb2xpY3kvcHJpdmFjeS1wb2xpY3kuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxpQkFBaUI7QUFDckIiLCJmaWxlIjoic3JjL2FwcC9wcml2YWN5LXBvbGljeS9wcml2YWN5LXBvbGljeS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLlBQRGV0YWlsc3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbn1cclxuLlBQRGV0YWlscyBoMntcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkZXI7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxufVxyXG4uUFBEZXRhaWxzIHB7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](PrivacyPolicyComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-privacy-policy',
                templateUrl: './privacy-policy.component.html',
                styleUrls: ['./privacy-policy.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/resources/resources.component.ts":
/*!**************************************************!*\
  !*** ./src/app/resources/resources.component.ts ***!
  \**************************************************/
/*! exports provided: ResourcesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResourcesComponent", function() { return ResourcesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class ResourcesComponent {
    constructor() { }
    ngOnInit() {
    }
}
ResourcesComponent.ɵfac = function ResourcesComponent_Factory(t) { return new (t || ResourcesComponent)(); };
ResourcesComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ResourcesComponent, selectors: [["app-resources"]], decls: 7, vars: 0, consts: [[1, "resourceHead"]], template: function ResourcesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Resource Center");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, "View industry reports, articles, customer case studies,");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, "ebooks, webinars and more.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".resourceHead[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 200px;\r\n    background-color: #6FDA44;\r\n    color: white;\r\n}\r\n.resourceHead[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n    margin-top: 10px;\r\n    margin-left: 40px;\r\n    font-size: 40px;\r\n    font-style:inherit;\r\n    font-weight: bolder;\r\n}\r\n.resourceHead[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    color: white;\r\n    font-size: 20px;\r\n    margin-top: 10px;\r\n    margin-left: 40px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVzb3VyY2VzL3Jlc291cmNlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLGFBQWE7SUFDYix5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjtBQUNBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGlCQUFpQjtJQUNqQixlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLG1CQUFtQjtBQUN2QjtBQUNBO0lBQ0ksWUFBWTtJQUNaLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsaUJBQWlCO0FBQ3JCIiwiZmlsZSI6InNyYy9hcHAvcmVzb3VyY2VzL3Jlc291cmNlcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlc291cmNlSGVhZHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM2RkRBNDQ7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuLnJlc291cmNlSGVhZCBoMntcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxuICAgIGZvbnQtc2l6ZTogNDBweDtcclxuICAgIGZvbnQtc3R5bGU6aW5oZXJpdDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkZXI7XHJcbn1cclxuLnJlc291cmNlSGVhZCBwe1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ResourcesComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-resources',
                templateUrl: './resources.component.html',
                styleUrls: ['./resources.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/search-result-header/search-result-header.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/search-result-header/search-result-header.component.ts ***!
  \************************************************************************/
/*! exports provided: SearchResultHeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchResultHeaderComponent", function() { return SearchResultHeaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



class SearchResultHeaderComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    toggle() {
        var ul = document.getElementsByClassName("ul")[0];
        ul.setAttribute("display", "flex");
        alert("flex");
    }
    check(val) {
        localStorage.setItem("searchResult", val);
        // this.router.navigateByUrl('/searchResult', { skipLocationChange: true });
        //  this.router.navigate(["/http://localhost:4200/searchResult"]);
        window.location.href = "http://localhost:4200/searchResult";
    }
}
SearchResultHeaderComponent.ɵfac = function SearchResultHeaderComponent_Factory(t) { return new (t || SearchResultHeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"])); };
SearchResultHeaderComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SearchResultHeaderComponent, selectors: [["app-search-result-header"]], decls: 28, vars: 0, consts: [[1, "left-nav"], ["routerLink", "/mainpage/home", 1, "logo"], [2, "color", "#018328"], [1, "search-input"], ["type", "text", 3, "keyup.enter"], ["box", ""], [1, "search-icon"], [1, "fa", "fa-search"], [1, "right-nav"], [1, "toggle-button", 3, "click"], [1, "bar"], [1, "item"], ["routerLink", "/mainpage/home", 1, "lnk"], ["routerLink", "/mainpage/contact", 1, "lnk"], ["routerLink", "/mainpage/signin", 1, "lnk"], ["routerLink", "/mainpage/signup"]], template: function SearchResultHeaderComponent_Template(rf, ctx) { if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "Free");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "lancing");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "input", 4, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("keyup.enter", function SearchResultHeaderComponent_Template_input_keyup_enter_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1); const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10); return ctx.check(_r0.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SearchResultHeaderComponent_Template_div_click_14_listener() { return ctx.toggle(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](16, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](17, "span", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "ul", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "li", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, "HOME");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "li", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](22, "CONTACT");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "li", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24, "SIGN IN");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](26, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](27, "SIGN UP");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterLink"]], styles: ["*[_ngcontent-%COMP%]{\r\n    margin: 0px;\r\n    padding: 0px;\r\n    \r\n}\r\nheader[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    padding: 10px 5%;\r\n}\r\n.left-nav[_ngcontent-%COMP%]{\r\n}\r\n.logo[_ngcontent-%COMP%]{\r\n    font-size: 20px;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\n.right-nav[_ngcontent-%COMP%]{\r\n    \r\n}\r\nul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n    display: inline-block;\r\n    margin-left: 10px ;\r\n   color: gray;\r\n}\r\n.lnk[_ngcontent-%COMP%]{\r\n    transition: all .5s ease;\r\n    outline: none;\r\n}\r\n.lnk[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 10px gray;\r\n    padding: 0px 10px;\r\n    border-radius: 10px;\r\n    color: white;\r\n    background-color: #018328;\r\n    cursor: pointer;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n    background-color: #018328;\r\n    color: white;\r\n    padding: 5px;\r\n    border: 0;\r\n    border-radius: 10px;\r\n    box-shadow: 5px 10px 10px #888888;\r\n    outline: none;\r\n}\r\nbutton[_ngcontent-%COMP%]:hover{\r\n    box-shadow: 5px 5px 5px  gray;\r\n    padding: 5px;\r\n    border-radius: 10px;\r\n}\r\n.toggle-button[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    display: none;\r\n    flex-direction: column;\r\n    justify-content: space-between;\r\n    right: 10%;\r\n    top:30px;\r\n    width: 30px;\r\n    height: 20px;\r\n\r\n}\r\n.toggle-button[_ngcontent-%COMP%]   .bar[_ngcontent-%COMP%]{\r\n    height: 4px;\r\n    width: 100%;\r\n    background-color: black;\r\n    border-radius: 10px;\r\n}\r\n@media all and (max-width:550px){\r\n    ul[_ngcontent-%COMP%]{\r\n        display: flex;\r\n        flex-direction: column;\r\n        width: 100%;\r\n    }\r\n    .toggle-button[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n    .right-nav[_ngcontent-%COMP%]{\r\n        width: 100%;\r\n    }\r\n    header[_ngcontent-%COMP%]{\r\n        flex-direction: column;\r\n        align-items: flex-start;\r\n    }\r\n  \r\n    ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]{\r\n        text-align: center;\r\n        padding: 10px;\r\n    }\r\n    ul.active[_ngcontent-%COMP%]{\r\n        display: flex;\r\n    }\r\n\r\n    .lnk[_ngcontent-%COMP%]:hover{\r\n        background-color: #018328;\r\n        padding: 10px;\r\n        color: white;\r\n    }\r\n\r\n}\r\n\r\n.search-input[_ngcontent-%COMP%]{\r\n   \r\n    position: relative;\r\n}\r\n.search-icon[_ngcontent-%COMP%]{\r\n    position: absolute;\r\n    top: 10%;\r\n    left: 5px;\r\n    color:#018328;\r\n}\r\n.search-input[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{\r\n    padding-left: 25px;\r\n    border-radius: 50px;\r\n    border: 2px solid #018328;\r\n    outline: none;\r\n    width: 300px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoLXJlc3VsdC1oZWFkZXIvc2VhcmNoLXJlc3VsdC1oZWFkZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osd0NBQXdDO0FBQzVDO0FBQ0E7SUFDSSxrQ0FBa0M7SUFDbEMsYUFBYTtJQUNiLDhCQUE4QjtJQUM5QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0lBQ0ksZUFBZTtJQUNmLGVBQWU7SUFDZixhQUFhO0FBQ2pCO0FBQ0E7O0FBRUE7QUFFQTtJQUNJLHFCQUFxQjtJQUNyQixrQkFBa0I7R0FDbkIsV0FBVztBQUNkO0FBQ0E7SUFDSSx3QkFBd0I7SUFDeEIsYUFBYTtBQUNqQjtBQUNBO0lBQ0ksNkJBQTZCO0lBQzdCLGlCQUFpQjtJQUNqQixtQkFBbUI7SUFDbkIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsYUFBYTtBQUNqQjtBQUVBO0lBQ0ksa0NBQWtDO0lBQ2xDLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLFNBQVM7SUFDVCxtQkFBbUI7SUFDbkIsaUNBQWlDO0lBQ2pDLGFBQWE7QUFDakI7QUFDQTtJQUNJLDZCQUE2QjtJQUM3QixZQUFZO0lBQ1osbUJBQW1CO0FBQ3ZCO0FBR0E7SUFDSSxrQkFBa0I7SUFDbEIsYUFBYTtJQUNiLHNCQUFzQjtJQUN0Qiw4QkFBOEI7SUFDOUIsVUFBVTtJQUNWLFFBQVE7SUFDUixXQUFXO0lBQ1gsWUFBWTs7QUFFaEI7QUFFQTtJQUNJLFdBQVc7SUFDWCxXQUFXO0lBQ1gsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtBQUN2QjtBQUVBO0lBQ0k7UUFDSSxhQUFhO1FBQ2Isc0JBQXNCO1FBQ3RCLFdBQVc7SUFDZjtJQUNBO1FBQ0ksYUFBYTtJQUNqQjtJQUNBO1FBQ0ksV0FBVztJQUNmO0lBQ0E7UUFDSSxzQkFBc0I7UUFDdEIsdUJBQXVCO0lBQzNCOztJQUVBO1FBQ0ksa0JBQWtCO1FBQ2xCLGFBQWE7SUFDakI7SUFDQTtRQUNJLGFBQWE7SUFDakI7O0lBRUE7UUFDSSx5QkFBeUI7UUFDekIsYUFBYTtRQUNiLFlBQVk7SUFDaEI7O0FBRUo7QUFFQSxlQUFlO0FBQ2Y7O0lBRUksa0JBQWtCO0FBQ3RCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsUUFBUTtJQUNSLFNBQVM7SUFDVCxhQUFhO0FBQ2pCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLHlCQUF5QjtJQUN6QixhQUFhO0lBQ2IsWUFBWTtBQUNoQjtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBdURHIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoLXJlc3VsdC1oZWFkZXIvc2VhcmNoLXJlc3VsdC1oZWFkZXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIip7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIHBhZGRpbmc6IDBweDtcclxuICAgIC8qIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7ICovXHJcbn1cclxuaGVhZGVye1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMTBweCA1JTtcclxufVxyXG4ubGVmdC1uYXZ7XHJcbn1cclxuLmxvZ297XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbi5yaWdodC1uYXZ7XHJcbiAgICBcclxufVxyXG5cclxudWwgbGl7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweCA7XHJcbiAgIGNvbG9yOiBncmF5O1xyXG59XHJcbi5sbmt7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjVzIGVhc2U7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbi5sbms6aG92ZXJ7XHJcbiAgICBib3gtc2hhZG93OiA1cHggNXB4IDEwcHggZ3JheTtcclxuICAgIHBhZGRpbmc6IDBweCAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMTgzMjg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcblxyXG5idXR0b257XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAxODMyODtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGJvcmRlcjogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3gtc2hhZG93OiA1cHggMTBweCAxMHB4ICM4ODg4ODg7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG59XHJcbmJ1dHRvbjpob3ZlcntcclxuICAgIGJveC1zaGFkb3c6IDVweCA1cHggNXB4ICBncmF5O1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuXHJcbi50b2dnbGUtYnV0dG9ue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICByaWdodDogMTAlO1xyXG4gICAgdG9wOjMwcHg7XHJcbiAgICB3aWR0aDogMzBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxuXHJcbn1cclxuXHJcbi50b2dnbGUtYnV0dG9uIC5iYXJ7XHJcbiAgICBoZWlnaHQ6IDRweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcblxyXG5AbWVkaWEgYWxsIGFuZCAobWF4LXdpZHRoOjU1MHB4KXtcclxuICAgIHVse1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxuICAgIC50b2dnbGUtYnV0dG9ue1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB9XHJcbiAgICAucmlnaHQtbmF2e1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgaGVhZGVye1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICB9XHJcbiAgXHJcbiAgICB1bCBsaXtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZzogMTBweDtcclxuICAgIH1cclxuICAgIHVsLmFjdGl2ZXtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgfVxyXG5cclxuICAgIC5sbms6aG92ZXJ7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAxODMyODtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIH1cclxuXHJcbn1cclxuXHJcbi8qIHNlYXJjaCBiYXIgKi9cclxuLnNlYXJjaC1pbnB1dHtcclxuICAgXHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLnNlYXJjaC1pY29ue1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMCU7XHJcbiAgICBsZWZ0OiA1cHg7XHJcbiAgICBjb2xvcjojMDE4MzI4O1xyXG59XHJcbi5zZWFyY2gtaW5wdXQgaW5wdXR7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgIzAxODMyODtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbn1cclxuXHJcbi8qXHJcbi5sZWZ0LW5hdntcclxuXHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgXHJcbn1cclxuLmxvZ297XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gXHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgbGVmdDogMTAlO1xyXG4gICAgXHJcbn1cclxuLnJpZ2h0LW5hdntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGhvdHBpbms7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgXHJcbn1cclxuXHJcbi8qIC5oZWFkZXItbGlua3N7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYXF1YW1hcmluZTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICByaWdodDogMTAlO1xyXG4gICBcclxufSBcclxudWx7XHJcbiAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICBiYWNrZ3JvdW5kLWNvbG9yOiBncmV5O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIHJpZ2h0OiAxMCU7XHJcbiAgICBcclxufVxyXG51bCBsaXtcclxuICAgIGJvcmRlcjogIDFweCBzb2xpZCBibHVldmlvbGV0O1xyXG4gIFxyXG4gICAgcGFkZGluZzoxMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgIFxyXG59ICovXHJcblxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SearchResultHeaderComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-search-result-header',
                templateUrl: './search-result-header.component.html',
                styleUrls: ['./search-result-header.component.css']
            }]
    }], function () { return [{ type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/search-result/search-result.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/search-result/search-result.component.ts ***!
  \**********************************************************/
/*! exports provided: SearchResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchResultComponent", function() { return SearchResultComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _devdata_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../devdata.service */ "./src/app/devdata.service.ts");
/* harmony import */ var _searchinteraction_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../searchinteraction.service */ "./src/app/searchinteraction.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _search_result_header_search_result_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../search-result-header/search-result-header.component */ "./src/app/search-result-header/search-result-header.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../mainpage-footer/mainpage-footer.component */ "./src/app/mainpage-footer/mainpage-footer.component.ts");








function SearchResultComponent_ul_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "li", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SearchResultComponent_ul_3_Template_li_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3); const i_r1 = ctx.$implicit; const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return ctx_r2.sendData(i_r1.email); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "View profile");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "hr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const i_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](i_r1.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](i_r1.cat);
} }
class SearchResultComponent {
    constructor(devs, interaction, router) {
        this.devs = devs;
        this.interaction = interaction;
        this.router = router;
        this.found = false;
        this.searchResult = [];
        this.datakeywords = ['data', 'datacience', 'data science'];
    }
    ngOnInit() {
        var found = false;
        this.category = localStorage.getItem("searchResult");
        var arr = this.category.split(" ");
        this.devs.GetDevData().subscribe((response) => {
            if (response.status == "ok") {
                response.data.forEach(element => {
                    for (let i = 0; arr.length > i; i++) {
                        console.log(element.category, arr[i]);
                        var catarray = element.category.split(" ");
                        for (let j = 0; catarray.length > j; j++) {
                            if (arr[i] == catarray[j]) {
                                this.searchResult.push({ name: element.name, email: element.email, cat: element.category[0].toUpperCase() + element.category.slice(1) });
                                console.log(this.searchResult);
                                found = true;
                            }
                            console.log(found);
                            console.log(this.searchResult);
                        }
                    }
                    //  console.log(this.category.split(","))
                });
            }
            if (found) {
                this.text = "No more data ";
            }
            else {
                this.text = "No Data Found";
            }
        });
    }
    sendData(d) {
        localStorage.setItem("devemail", d);
        this.router.navigate(["/devprofile"]);
        if ("data" in this.datakeywords) {
            console.log("He");
        }
    }
}
SearchResultComponent.ɵfac = function SearchResultComponent_Factory(t) { return new (t || SearchResultComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_searchinteraction_service__WEBPACK_IMPORTED_MODULE_2__["SearchinteractionService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"])); };
SearchResultComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SearchResultComponent, selectors: [["app-search-result"]], decls: 8, vars: 2, consts: [[1, "searchHeader"], [1, "list-div"], [4, "ngFor", "ngForOf"], [1, "notfound-text"], [1, "lst", 3, "click"], [1, "icon"], ["src", "../../assets/usericon.png", "alt", "", 1, "imgBelowListDiv"], [1, "info"], ["type", "submit", 1, "btn", "btn-success"]], template: function SearchResultComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-search-result-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SearchResultComponent_ul_3_Template, 12, 2, "ul", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "app-mainpage-footer");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.searchResult);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.text);
    } }, directives: [_search_result_header_search_result_header_component__WEBPACK_IMPORTED_MODULE_4__["SearchResultHeaderComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"], _mainpage_footer_mainpage_footer_component__WEBPACK_IMPORTED_MODULE_6__["MainpageFooterComponent"]], styles: ["*[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n}\r\n.searchHeader[_ngcontent-%COMP%]{\r\n    position: relative;\r\n    margin-top: 5%;\r\n    \r\n\r\n    \r\n\r\n}\r\n.list-div[_ngcontent-%COMP%]{\r\n    \r\n    top: 10%;\r\n    width: 80%;\r\n    position: relative;\r\n    left: 50%;\r\n    transform: translate(-50%);\r\n\r\n}\r\nimg[_ngcontent-%COMP%]{\r\n    height: 90px;\r\n    width: 80px;\r\n\r\n}\r\n.lst[_ngcontent-%COMP%]{\r\n    display: flex;\r\n}\r\n.icon[_ngcontent-%COMP%]{\r\n    position: relative;\r\n    left: 10px;\r\n    top: 10px;\r\n    color: green;\r\n}\r\n.info[_ngcontent-%COMP%]{\r\n    margin-left: 30px;\r\n}\r\nli[_ngcontent-%COMP%]{\r\n    height: 120px;\r\n    box-shadow: 0 0 5px gray;\r\n}\r\n.notfound-text[_ngcontent-%COMP%]{\r\n    text-align: center;\r\n    \r\n}\r\n.notfound-text[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n   color: red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoLXJlc3VsdC9zZWFyY2gtcmVzdWx0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQ0FBa0M7QUFDdEM7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2Qsa0JBQWtCOztJQUVsQix3QkFBd0I7O0FBRTVCO0FBRUE7SUFDSSw0QkFBNEI7SUFDNUIsUUFBUTtJQUNSLFVBQVU7SUFDVixrQkFBa0I7SUFDbEIsU0FBUztJQUNULDBCQUEwQjs7QUFFOUI7QUFFQTtJQUNJLFlBQVk7SUFDWixXQUFXOztBQUVmO0FBQ0E7SUFDSSxhQUFhO0FBQ2pCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLFNBQVM7SUFDVCxZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxpQkFBaUI7QUFDckI7QUFDQTtJQUNJLGFBQWE7SUFDYix3QkFBd0I7QUFDNUI7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQiw0QkFBNEI7QUFDaEM7QUFDQTtHQUNHLFVBQVU7QUFDYjtBQVNDLG1CQUFtQjtBQUNoQixpQkFBaUI7QUFDakI7O0dBRUQ7QUFDSDs7Ozs7O21CQU1tQjtBQUNmLGVBQWU7QUFDZixlQUFlO0FBQ25CLE9BQU87QUFDUDs7R0FFRztBQUVIOzs7Ozs7RUFNRTtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7R0FlRztBQUVGOzs7Ozs7O0dBT0U7QUFDSDs7OztHQUlHIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoLXJlc3VsdC9zZWFyY2gtcmVzdWx0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIqe1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxufVxyXG4uc2VhcmNoSGVhZGVye1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgICAvKiBoZWlnaHQ6IDkwdmg7ICovXHJcblxyXG4gICAgLyogb3ZlcmZsb3cteTogc2Nyb2xsOyAqL1xyXG5cclxufSBcclxuXHJcbi5saXN0LWRpdntcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IGFxdWE7ICovXHJcbiAgICB0b3A6IDEwJTtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcclxuXHJcbn1cclxuXHJcbmltZ3tcclxuICAgIGhlaWdodDogOTBweDtcclxuICAgIHdpZHRoOiA4MHB4O1xyXG5cclxufVxyXG4ubHN0e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxufVxyXG4uaWNvbntcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IDEwcHg7XHJcbiAgICB0b3A6IDEwcHg7XHJcbiAgICBjb2xvcjogZ3JlZW47XHJcbn1cclxuLmluZm97XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxufVxyXG5saXtcclxuICAgIGhlaWdodDogMTIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDAgNXB4IGdyYXk7XHJcbn1cclxuIFxyXG4ubm90Zm91bmQtdGV4dHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC8qIGJhY2tncm91bmQtY29sb3I6IGFxdWE7ICovXHJcbn1cclxuLm5vdGZvdW5kLXRleHQgaDJ7XHJcbiAgIGNvbG9yOiByZWQ7XHJcbn1cclxuIFxyXG4gXHJcbiBcclxuIFxyXG4gXHJcbiBcclxuIFxyXG4gXHJcbiAvKiAuc2VhcmNoSGVhZGVyeyAqL1xyXG4gICAgLyogd2lkdGg6IDEwMCU7ICovXHJcbiAgICAvKiBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjJGMkYyO1xyXG59ICovXHJcbi8qIC5zZWFyY2hIZWFke1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogNTAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogNDBweDtcclxuICAgIC8qIHRvcDogODBweDsgKi9cclxuICAgIC8qIGxlZnQ6IDEwJTsgKi9cclxuICAgIC8qIGxlZnQ6IDEwJTsgKi9cclxuLyogfSAgKi9cclxuLyogLmxpc3QtZGl2e1xyXG4gICAgXHJcbn0gKi9cclxuXHJcbi8qIDw8PDw8PDwgSEVBRFxyXG4ubGlzdC1kaXZ7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0b3A6IDUlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG59Ki9cclxuLyogdWwgbGl7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMjBweCAycHggZ3JheTsgXHJcblxyXG59XHJcbi5zZWFyY2hIZWFkIGgxe1xyXG5cclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmltZ0JlbG93TGlzdERpdntcclxuICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG59ICovXHJcblxyXG4gLyogLmxpc3QtZGl2IHVsIHVsIGgye1xyXG4gICAgIGNvbG9yOiAjMDA4MzI5O1xyXG59XHJcbi51bHVse1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbGVmdDogNjBweDtcclxuICAgIHRvcDogLTgwcHg7XHJcbn0gKi9cclxuLyogLmJ0bntcclxuICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgaGVpZ2h0OiAzcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzE4MzI5O1xyXG59ICovICAiXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SearchResultComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-search-result',
                templateUrl: './search-result.component.html',
                styleUrls: ['./search-result.component.css']
            }]
    }], function () { return [{ type: _devdata_service__WEBPACK_IMPORTED_MODULE_1__["DevdataService"] }, { type: _searchinteraction_service__WEBPACK_IMPORTED_MODULE_2__["SearchinteractionService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }]; }, null); })();


/***/ }),

/***/ "./src/app/searchinteraction.service.ts":
/*!**********************************************!*\
  !*** ./src/app/searchinteraction.service.ts ***!
  \**********************************************/
/*! exports provided: SearchinteractionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchinteractionService", function() { return SearchinteractionService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");



class SearchinteractionService {
    constructor() {
        this.searchValueSource = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        this.searchMessage$ = this.searchValueSource.asObservable();
    }
    sendSearchValue(msg) {
        this.searchValueSource.next(msg);
    }
}
SearchinteractionService.ɵfac = function SearchinteractionService_Factory(t) { return new (t || SearchinteractionService)(); };
SearchinteractionService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: SearchinteractionService, factory: SearchinteractionService.ɵfac, providedIn: 'root' });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SearchinteractionService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/signup/signup.component.ts":
/*!********************************************!*\
  !*** ./src/app/signup/signup.component.ts ***!
  \********************************************/
/*! exports provided: SignupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupComponent", function() { return SignupComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data.service */ "./src/app/data.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _devdata_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../devdata.service */ "./src/app/devdata.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");







function SignupComponent_span_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this is a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_12_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Enter vaild email");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SignupComponent_div_12_span_1_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.touched && _r1.errors.pattern);
} }
function SignupComponent_div_16_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_16_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " minimum length should be 8 charcters ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_16_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "Format: 123-456-7890");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SignupComponent_div_16_span_1_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, SignupComponent_div_16_span_2_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SignupComponent_div_16_span_3_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.required);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.minlength);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.touched && _r4.errors.pattern);
} }
function SignupComponent_div_20_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_20_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" minimum length should be ", _r6.errors.minlength.requiredLength, " charcters ");
} }
function SignupComponent_div_20_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "at least one letter, one number and one special character");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SignupComponent_div_20_span_1_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, SignupComponent_div_20_span_2_Template, 2, 1, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SignupComponent_div_20_span_3_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r6.touched && _r6.errors.required);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r6.touched && _r6.errors.minlength);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r6.touched && _r6.errors.pattern);
} }
function SignupComponent_div_24_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " this a required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
function SignupComponent_div_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SignupComponent_div_24_span_1_Template, 2, 0, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r8.touched && _r8.errors.required);
} }
class SignupComponent {
    constructor(ds, router, dvs) {
        this.ds = ds;
        this.router = router;
        this.dvs = dvs;
        this.nameProp = "";
        this.emailProp = "";
        this.passwordProp = "";
        this.mobileNoProp = "";
        this.confirmPassProp = "";
    }
    ngOnInit() {
    }
    signUP() {
        var acFound = false;
        if (this.nameProp != "" && this.emailProp != "" && this.passwordProp != "" && this.mobileNoProp != "") {
            this.ds.signIn({ email: this.emailProp })
                .subscribe((response) => {
                if (response.status == "ok") {
                    alert("Account Already Exist");
                }
                else {
                    if (this.passwordProp == this.confirmPassProp) {
                        this.ds.signUp({ name: this.nameProp, email: this.emailProp, password: this.passwordProp, phone: this.mobileNoProp })
                            .subscribe((response) => {
                            if (response.status == "ok") {
                                this.dvs.sendMail({ clientemail: this.emailProp, name: this.nameProp }).subscribe(res => {
                                    alert(res.err);
                                });
                                alert("Sign Up Successfull you will be redirected to sign in ");
                                this.router.navigate(['/mainpage/signin']);
                            }
                        });
                    }
                    else {
                        alert("confirmed password not matched!");
                    }
                }
                // if(response.status=="ok")
                // {
                //   response.data.forEach(element => {
                //     if(element.email==this.emailProp){
                //       console.log(element.email,this.emailProp)
                //     acFound=true
                //     }
                //   });
                // }
                // if(acFound){
                //   alert("Account Already Exist")
                // }
                // else if(this.passwordProp==this.confirmPassProp){
                //        this.ds.signUp({name:this.nameProp, email:this.emailProp, password:this.passwordProp ,phone:this.mobileNoProp})
                //   .subscribe((response)=>{
                //     if(response.status=="ok")
                //     {
                //         alert("Sign Up Successfull you will be redirected to sign in ");
                //         this.router.navigate(['/mainpage/signin']);
                //     }
                //   })
                // }
                // else{
                //   alert("confirmed password not matched!")
                // }
            });
        }
        else {
            alert("fill all filds!");
        }
    }
}
SignupComponent.ɵfac = function SignupComponent_Factory(t) { return new (t || SignupComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_devdata_service__WEBPACK_IMPORTED_MODULE_3__["DevdataService"])); };
SignupComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SignupComponent, selectors: [["app-signup"]], decls: 27, vars: 11, consts: [[1, "one"], [1, "two"], [1, "p1"], ["ngNativeValidate", ""], ["userForm", "ngForm"], [1, "form-group"], ["type", "name", "name", "fullname", "placeholder", "FullName", "id", "name", "required", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["type", "email", "name", "email", "placeholder", "Email", "id", "email", "pattern", "^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$", "required", "", 1, "form-control", 3, "ngModel", "ngModelChange"], ["emailRef", "ngModel"], [4, "ngIf"], ["type", "tel", "name", "mobileno", "placeholder", "Mobile Number", "id", "mobNo", "placeholder", "123-456-7890", "pattern", "[0-9]{3}-[0-9]{3}-[0-9]{4}", "required", "", "minlength", "10", 1, "form-control", 3, "ngModel", "ngModelChange"], ["mobileRef", "ngModel"], ["type", "password", "name", "pwd", "placeholder", "Password", "id", "pwd", "pattern", "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$", "required", "", "minlength", "8", 1, "form-control", 3, "ngModel", "ngModelChange"], ["passRef", "ngModel"], ["required", "", "type", "password", "name", "confirmpassword", "placeholder", "Confirm Password", "id", "confirmPwd", 1, "form-control", 3, "ngModel", "ngModelChange"], ["CpassRef", "ngModel"], ["type", "submit", 1, "btn", "btn-success", 3, "disabled", "click"]], template: function SignupComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Get your free account");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "form", 3, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function SignupComponent_Template_input_ngModelChange_7_listener($event) { return ctx.nameProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "input", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function SignupComponent_Template_input_ngModelChange_9_listener($event) { return ctx.emailProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](11, SignupComponent_span_11_Template, 2, 0, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, SignupComponent_div_12_Template, 2, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "input", 10, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function SignupComponent_Template_input_ngModelChange_14_listener($event) { return ctx.mobileNoProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, SignupComponent_div_16_Template, 4, 3, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "input", 12, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function SignupComponent_Template_input_ngModelChange_18_listener($event) { return ctx.passwordProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](20, SignupComponent_div_20_Template, 4, 3, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](21, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "input", 14, 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function SignupComponent_Template_input_ngModelChange_22_listener($event) { return ctx.confirmPassProp = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, SignupComponent_div_24_Template, 2, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](25, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SignupComponent_Template_button_click_25_listener() { return ctx.signUP(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](26, "Register");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](5);
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10);
        const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](15);
        const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](19);
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.nameProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.emailProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.touched && _r1.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r1.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.mobileNoProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r4.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.passwordProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r6.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.confirmPassProp);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", _r8.errors);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", _r0.form.invalid);
    } }, directives: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgForm"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["RequiredValidator"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["PatternValidator"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["MinLengthValidator"]], styles: ["*[_ngcontent-%COMP%]{\r\n    font-family: 'Poppins', sans-serif;\r\n}\r\n.one[_ngcontent-%COMP%]{\r\n\r\n    height: 100%;\r\n    background-color:#F2F2F2;\r\n    color: black;\r\n    position: relative;\r\n    padding: 5%;\r\n   \r\n}\r\n.two[_ngcontent-%COMP%]{\r\n    width: 550px;\r\n    height: 100%;\r\n    background-color: white;\r\n    position: relative;\r\n    text-align: center;\r\n    font-family: sans-serif;\r\n    font-size: 30px;\r\n    \r\n    left: 50%;\r\n    padding-top: 5%;\r\n    padding-bottom: 5%;\r\n    transform: translate(-50%);\r\n}\r\n.p1[_ngcontent-%COMP%]{\r\n    \r\n}\r\n.btn[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    background-color:#008329;\r\n}\r\n#name[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n#email[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n#mobNo[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n#pwd[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n#confirmPwd[_ngcontent-%COMP%]{\r\n    width: 400px;\r\n    margin-left: 75px;\r\n}\r\n.p2[_ngcontent-%COMP%]{\r\n    margin-top: 100px;\r\n}\r\nspan[_ngcontent-%COMP%]{\r\n    color: red;\r\n    font-size: 15px;\r\n}\r\n.form-control.ng-touched.ng-invalid[_ngcontent-%COMP%]{\r\n    border: 2px solid red;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbnVwL3NpZ251cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0NBQWtDO0FBQ3RDO0FBQ0E7O0lBRUksWUFBWTtJQUNaLHdCQUF3QjtJQUN4QixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFdBQVc7O0FBRWY7QUFDQTtJQUNJLFlBQVk7SUFDWixZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLGVBQWU7SUFDZixjQUFjO0lBQ2QsU0FBUztJQUNULGVBQWU7SUFDZixrQkFBa0I7SUFDbEIsMEJBQTBCO0FBQzlCO0FBQ0E7SUFDSSxzQkFBc0I7QUFDMUI7QUFDQTtJQUNJLFlBQVk7SUFDWix3QkFBd0I7QUFDNUI7QUFDQTtJQUNJLFlBQVk7SUFDWixpQkFBaUI7QUFDckI7QUFDQTtJQUNJLFlBQVk7SUFDWixpQkFBaUI7QUFDckI7QUFDQTtJQUNJLFlBQVk7SUFDWixpQkFBaUI7QUFDckI7QUFDQTtJQUNJLFlBQVk7SUFDWixpQkFBaUI7QUFDckI7QUFDQTtJQUNJLFlBQVk7SUFDWixpQkFBaUI7QUFDckI7QUFDQTtJQUNJLGlCQUFpQjtBQUNyQjtBQUVBO0lBQ0ksVUFBVTtJQUNWLGVBQWU7QUFDbkI7QUFFQTtJQUNJLHFCQUFxQjtBQUN6QiIsImZpbGUiOiJzcmMvYXBwL3NpZ251cC9zaWdudXAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIip7XHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG59XHJcbi5vbmV7XHJcblxyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjojRjJGMkYyO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgcGFkZGluZzogNSU7XHJcbiAgIFxyXG59XHJcbi50d297XHJcbiAgICB3aWR0aDogNTUwcHg7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgLyogdG9wOiA1MCU7ICovXHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICBwYWRkaW5nLXRvcDogNSU7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNSU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcclxufVxyXG4ucDF7XHJcbiAgICAvKiBtYXJnaW4tdG9wOiA1MHB4OyAqL1xyXG59XHJcbi5idG57XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiMwMDgzMjk7XHJcbn1cclxuI25hbWV7XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNzVweDtcclxufVxyXG4jZW1haWx7XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNzVweDtcclxufVxyXG4jbW9iTm97XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNzVweDtcclxufVxyXG4jcHdke1xyXG4gICAgd2lkdGg6IDQwMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDc1cHg7XHJcbn1cclxuI2NvbmZpcm1Qd2R7XHJcbiAgICB3aWR0aDogNDAwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogNzVweDtcclxufVxyXG4ucDJ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMDBweDtcclxufVxyXG5cclxuc3BhbntcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuXHJcbi5mb3JtLWNvbnRyb2wubmctdG91Y2hlZC5uZy1pbnZhbGlke1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG59Il19 */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](SignupComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-signup',
                templateUrl: './signup.component.html',
                styleUrls: ['./signup.component.css']
            }]
    }], function () { return [{ type: _data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"] }, { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }, { type: _devdata_service__WEBPACK_IMPORTED_MODULE_3__["DevdataService"] }]; }, null); })();


/***/ }),

/***/ "./src/app/terms-of-services/terms-of-services.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/terms-of-services/terms-of-services.component.ts ***!
  \******************************************************************/
/*! exports provided: TermsOfServicesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsOfServicesComponent", function() { return TermsOfServicesComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class TermsOfServicesComponent {
    constructor() { }
    ngOnInit() {
    }
}
TermsOfServicesComponent.ɵfac = function TermsOfServicesComponent_Factory(t) { return new (t || TermsOfServicesComponent)(); };
TermsOfServicesComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TermsOfServicesComponent, selectors: [["app-terms-of-services"]], decls: 15, vars: 0, consts: [[1, "tosDetails"]], template: function TermsOfServicesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "User Agreement");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4, " PLEASE READ THIS USER AGREEMENT AND ALL OTHER AGREEMENTS AND POLICIES REFERENCED HEREIN COLLECTIVELY DEFINED BELOW AS THE \"TERMS OF SERVICE\" CAREFULLY AS THEY CONTAIN IMPORTANT INFORMATION REGARDING YOUR LEGAL RIGHTS, REMEDIES, AND OBLIGATIONS. THESE INCLUDE VARIOUS LIMITATIONS AND EXCLUSIONS AND A BINDING ARBITRATION AGREEMENT AND CLASS ACTION WAIVER.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " This User Agreement (this \u201CAgreement\u201D) is a contract between you (\u201Cyou\u201D or \u201CUser\u201D) Upwork Global Inc. (\u201CFreelancing,\u201D \u201Cwe,\u201D or \u201Cus\u201D) and our affiliates Upwork Escrow Inc. (\u201CFreelancing Escrow\u201D) and, to the extent expressly stated, Elance Limited (\"Elance Ltd.\"). You must read, agree to, and accept all of the terms and conditions contained in this Agreement to be a User of our website located at www.upwork.com or any part of the rest of the Site (defined in the Site Terms of Use) or the Site Services (defined in the Site Terms of Use).\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, " This Agreement includes and hereby incorporates by reference the following important agreements, as they may be in effect and modified from time to time: Site Terms of Use; Fee and ACH Authorization Agreement; Cookie Policy; Privacy Policy; Mark Use Guidelines; Freelancer Membership Agreement; Proprietary Rights Infringement Reporting Procedures; Upwork App Software License Agreement; API Terms of Use; and the escrow instructions as applicable to any Service Contract you enter into with another User, specifically the Hourly, Bonus, and Expense Payment Agreement with Escrow Instructions; and Fixed-Price Escrow Instructions. This Agreement also incorporates, for any User using the Upwork Direct Contract Service, Upwork Direct Contract Terms and Direct Contract Escrow Instructions. These agreements are collectively, with this Agreement, called the \u201CTerms of Service\u201D.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, " Subject to the conditions set forth herein, Upwork may, in its sole discretion, amend this Agreement and the other Terms of Service at any time by posting a revised version on the Site. Upwork will provide reasonable advance notice of any amendment that includes a Substantial Change (defined below), by posting the updated Terms of Service on the Site, providing notice on the Site, and/or sending you notice by email. If the Substantial Change includes an increase to Fees charged by Upwork, Upwork will provide at least 30 days\u2019 advance notice of the change, but may not provide any advance notice for changes resulting in a reduction in Fees or any temporary or promotional Fee change. Any revisions to the Terms of Service will take effect on the noted effective date (each, as applicable, the \u201CEffective Date\u201D).\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12, " YOU UNDERSTAND THAT BY USING THE SITE OR SITE SERVICES AFTER THE EFFECTIVE DATE, YOU AGREE TO BE BOUND BY THE TERMS OF SERVICE, INCLUDING THE ARBITRATION PROVISION IN SECTION 14 OF THIS AGREEMENT (SUBJECT TO YOUR RIGHT TO OPT OUT OF THE ARBITRATION PROVISION AS PROVIDED IN SECTION 14). IF YOU DO NOT ACCEPT THE TERMS OF SERVICE IN ITS ENTIRETY, YOU MUST NOT ACCESS OR USE THE SITE OR THE SITE SERVICES AFTER THE EFFECTIVE DATE EXCEPT AS PERMITTED BY THE SITE TERMS OF USE.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14, " IF YOU AGREE TO THE TERMS OF SERVICE ON BEHALF OF AN ENTITY OR AGENCY, OR IN CONNECTION WITH PROVIDING OR RECEIVING SERVICES ON BEHALF OF AN ENTITY OR AGENCY, YOU REPRESENT AND WARRANT THAT YOU HAVE THE AUTHORITY TO BIND THAT ENTITY OR AGENCY TO THE TERMS OF SERVICE AND AGREE THAT YOU ARE BINDING BOTH YOU AND THAT ENTITY OR AGENCY TO THE TERMS OF SERVICE. IN THAT EVENT, \u201CYOU\u201D AND \u201CYOUR\u201D WILL REFER AND APPLY TO YOU AND THAT ENTITY OR AGENCY.\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".tosDetails[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    height: 100%;\r\n    background-color: white;\r\n    color: black;\r\n}\r\n.tosDetails[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%]{\r\n    font-weight: bolder;\r\n    color: black;\r\n    margin-left: 30px;\r\n}\r\n.tosDetails[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{\r\n    margin-left: 30px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVybXMtb2Ytc2VydmljZXMvdGVybXMtb2Ytc2VydmljZXMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osdUJBQXVCO0lBQ3ZCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxpQkFBaUI7QUFDckIiLCJmaWxlIjoic3JjL2FwcC90ZXJtcy1vZi1zZXJ2aWNlcy90ZXJtcy1vZi1zZXJ2aWNlcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvc0RldGFpbHN7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG59XHJcbi50b3NEZXRhaWxzIGgye1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG59XHJcbi50b3NEZXRhaWxzIHB7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxufSJdfQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TermsOfServicesComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-terms-of-services',
                templateUrl: './terms-of-services.component.html',
                styleUrls: ['./terms-of-services.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/app/who-you-are/who-you-are.component.ts":
/*!******************************************************!*\
  !*** ./src/app/who-you-are/who-you-are.component.ts ***!
  \******************************************************/
/*! exports provided: WhoYouAreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhoYouAreComponent", function() { return WhoYouAreComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


class WhoYouAreComponent {
    constructor() { }
    ngOnInit() {
    }
}
WhoYouAreComponent.ɵfac = function WhoYouAreComponent_Factory(t) { return new (t || WhoYouAreComponent)(); };
WhoYouAreComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: WhoYouAreComponent, selectors: [["app-who-you-are"]], decls: 6, vars: 0, template: function WhoYouAreComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "You are a: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "button");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Developer");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "client");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3doby15b3UtYXJlL3doby15b3UtYXJlLmNvbXBvbmVudC5jc3MifQ== */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](WhoYouAreComponent, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'app-who-you-are',
                templateUrl: './who-you-are.component.html',
                styleUrls: ['./who-you-are.component.css']
            }]
    }], function () { return []; }, null); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\sumant\Desktop\projects\new4\Freelancing\FrontEnd\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map